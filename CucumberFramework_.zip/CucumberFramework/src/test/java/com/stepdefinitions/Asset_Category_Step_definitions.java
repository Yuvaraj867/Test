package com.stepdefinitions;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.lao.Exceldata.TestDataInitializer;
import com.lao.pageobjects.IFAC_Asset_Category;
import com.lao.pageobjects.IFAC_Work_Group;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Asset_Category_Step_definitions {

	static Logger logger = Logger.getLogger(Common_Step_definition.class);
	WebDriver driver;
	TestDataInitializer dataInitializer;
	Map<String, String> testData;

	public Asset_Category_Step_definitions() throws IOException {
		// Initialize test data for the sheet and retrieve data for specific test case
		dataInitializer = new TestDataInitializer("D:\\Excel\\Asset_Category_Test_Data.xlsx", "Sheet1");
		testData = dataInitializer.getTestData("ACTest");
	}

	@And("the user click on the Asset Category menu")
	public void the_user_click_on_the_asset_category_menu() {
		IFAC_Asset_Category.getAssetCategoryinstance().selectAssetCategory();

	}

	@Then("the user navigate into the Asset Category page")
	public void the_user_navigate_into_the_asset_category_page() {
		System.out.println("the user is on the Asset Category page");
	}

	@Then("the user navigate into the Create Asset Category Page")
	public void the_user_navigate_into_the_create_asset_category_page() {
		System.out.println("the user is on the Create Asset Category Page");

	}

	@When("the user enters the Asset Category Code {string}")
	public void the_user_enters_the_asset_category_code(String enterACCode) {
		String datetime12 = new SimpleDateFormat("ssyy").format(new Date());
		
		IFAC_Asset_Category.getAssetCategoryinstance().enterAssetCategoryCode(testData.get(enterACCode));
		IFAC_Asset_Category.getAssetCategoryinstance().enterAssetCategoryCode(datetime12);

	}

	@When("the user enters the Asset Category Description {string}")
	public void the_user_enters_the_asset_category_description(String enterACDesc) {
		IFAC_Asset_Category.getAssetCategoryinstance().enterAssetCategoryDescription(testData.get(enterACDesc));

	}

	@Then("the user successfully Created the New Asset Category")
	public void the_user_successfully_created_the_new_asset_category() {
		System.out.println("the user successfully Created the New Asset Category");

	}

	@When("the user enters the New Asset Category Code {string}")
	public void the_user_enters_the_new_asset_category_code(String enterNewActCode) {
		IFAC_Work_Group.getWorkgroupinstance().selectService();
		String datetime15 = new SimpleDateFormat("ssyy").format(new Date());
		IFAC_Asset_Category.getAssetCategoryinstance().enterNewAssetCategoryCode(testData.get(enterNewActCode));
		IFAC_Asset_Category.getAssetCategoryinstance().enterNewAssetCategoryCode(datetime15);

	}

	@When("the user enters the New Asset Category Description {string}")
	public void the_user_enters_the_new_asset_category_description(String enterNewActDes) {
		IFAC_Asset_Category.getAssetCategoryinstance().enterNewAssetCategoryDescription(testData.get(enterNewActDes));

	}

	@Then("the user allows to create a New Asset Category")
	public void the_user_allows_to_create_a_new_asset_category() {
		System.out.println(" the user allows to create a New Asset Category");
	}

	@Then("the user navigate into Asset Category page")
	public void the_user_navigate_into_asset_category_page() {
		System.out.println("the user navigate into Asset Category page");

	}

	@Given("the user is on the Asset Category page")
	public void the_user_is_on_the_asset_category_page() {
		System.out.println("the user is on the Asset Category list page");

	}

	@When("the user clicks on the edit icon of the required Asset Category {string}")
	public void the_user_clicks_on_the_edit_icon_of_the_required_asset_category(String enterACCode) {
		IFAC_Asset_Category.getAssetCategoryinstance().enterAssetCategoryFilter(testData.get(enterACCode)); 
		IFAC_Work_Group.getWorkgroupinstance().clickEditIcon();

	}

	@Then("the user navigate into the Asset Category edit page")
	public void the_user_navigate_into_the_asset_category_edit_page() {
		System.out.println("the user navigate into the Asset Category edit page");
	}

	@When("the user allows to edit the Asset Category Description {string}")
	public void the_user_allows_to_edit_the_asset_category_description(String ACDesc) {

		IFAC_Asset_Category.getAssetCategoryinstance().enterAssetCategoryDescription(testData.get(ACDesc)); 
	}

	@Then("the user successfully Updated  the  Asset Category")
	public void the_user_successfully_updated_the_asset_category() {
		System.out.println("the user successfully Updated  the  Asset Category");

	}

	@Then("the user navigate into the Asset Category Screen")
	public void the_user_navigate_into_the_Asset_Category_screen() {
		System.out.println("the user navigate into the Asset Category  list Screen");

	}

	@When("the user enter the Asset Category Code {string} in search field")
	public void the_user_enter_the_asset_category_code_in_search_field(String enterACCode) {
		IFAC_Asset_Category.getAssetCategoryinstance().enterAssetCategoryFilter(testData.get(enterACCode)); 

	}

	@Then("the user navigate into the View Asset Category page")
	public void the_user_navigate_into_the_view_asset_category_page() {
		System.out.println("the user navigate into the View Asset Category page");

	}

	@When("the user deleted the required Asset Category")
	public void the_user_deleted_the_required_asset_category() {

		System.out.println("the user delete the Asset Category");

	}

	
	
	@When("the user enter the Invalid data in Asset Category Code {string} and Asset Category Description {string}")
	public void the_user_enter_the_invalid_data_in_asset_category_code_and_asset_category_description(String IACCODE, String IACDESC) {
	    IFAC_Work_Group.getWorkgroupinstance().selectService();
	    IFAC_Asset_Category.getAssetCategoryinstance().enterInvalidAssetCategoryCode(testData.get(IACCODE));
	    IFAC_Asset_Category.getAssetCategoryinstance().enterInvalidAssetCategoryDescription(testData.get(IACDESC));
	    
	}

}
