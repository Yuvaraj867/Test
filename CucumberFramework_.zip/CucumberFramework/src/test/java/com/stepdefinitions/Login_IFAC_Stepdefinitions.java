package com.stepdefinitions;

import java.io.IOException;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;

import com.lao.Exceldata.TestDataInitializer;
import com.lao.pageobjects.IFAC_Login;
import com.lao.pageobjects.IFAC_Work_Group;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Login_IFAC_Stepdefinitions {
     WebDriver driver;
     TestDataInitializer dataInitializer;
	    Map<String, String> testData;

	    public Login_IFAC_Stepdefinitions() throws IOException {
	        // Initialize test data for the sheet and retrieve data for specific test case
	        dataInitializer = new TestDataInitializer("D:\\Excel\\Login_Data.xlsx", "Sheet2");
	        testData = dataInitializer.getTestData("LoginTest1");}
	
	@Given("the User is on the login page with Url")
	public void the_user_is_on_the_login_page_with_url() {
		
		IFAC_Login.getInstance().navigateToUrl(testData.get("URL"));
		
		
	    
	}
	@When("the User leaves Username and Password empty")
	public void the_user_leaves_username_and_password_empty() {
		System.out.println("the user empty the username and password field");
	    
	}
	@When("the User click the login")
	public void the_user_click_the_login() {
		IFAC_Login.getInstance().Login();
	    
	}
	
	@When("the User types a Invalid {string} and {string}")
	public void the_user_enter_a_Invalid_and(String enterIusername, String enterIpassword) {
		IFAC_Login.getInstance().InvalidUsername(testData.get(enterIusername));;
		IFAC_Login.getInstance().InvalidPassword(testData.get(enterIpassword));;
	    
	}

	@When("the User click the login button")
	public void the_user_click_the_login_button() {
		IFAC_Login.getInstance().Login();
	}

	@When("the User types a valid {string} and {string}")
	public void the_user_types_a_valid_and(String enterVUsername, String enterVPassword) throws InterruptedException {
		IFAC_Login.getInstance().Username(testData.get(enterVUsername));
		IFAC_Login.getInstance().Password(testData.get(enterVPassword));
	}

	@When("the User select the Keep Me Logged in Checkbox")
	public void the_user_select_the_keep_me_logged_in_checkbox() {
	   IFAC_Login.getInstance().KeepMecheckbox();
	}

	@When("the User click the Login button")
	public void the_user_click_the_Login_button() {
		IFAC_Login.getInstance().Login();
	}

}
