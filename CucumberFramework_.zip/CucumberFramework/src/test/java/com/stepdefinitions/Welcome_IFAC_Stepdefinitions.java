package com.stepdefinitions;


import java.io.IOException;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import com.lao.Exceldata.TestDataInitializer;
import com.lao.pageobjects.IFAC_Login;
import com.lao.pageobjects.IFAC_Welcome_Page;
import com.lao.pageobjects.IFAC_Work_Group;

import WEBDRIVER_Manager.DriverManager;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Welcome_IFAC_Stepdefinitions {
	
	WebDriver driver;
    TestDataInitializer dataInitializer;
	    Map<String, String> testData;

	    public Welcome_IFAC_Stepdefinitions() throws IOException {
	        // Initialize test data for the sheet and retrieve data for specific test case
	        dataInitializer = new TestDataInitializer("D:\\Excel\\Login_Data.xlsx", "Sheet2");
	        testData = dataInitializer.getTestData("LoginTest1");}
	    @Given("the user successfully login to the application with {string} , {string}")
	    public void the_user_successfully_login_to_the_application_with(String enterVUsername, String enterVPassword) {
	       
		
		IFAC_Login.getInstance().navigateToUrl(testData.get("URL"));
		IFAC_Login.getInstance().Username(testData.get(enterVUsername));
		IFAC_Login.getInstance().Password(testData.get(enterVPassword));
		IFAC_Login.getInstance().KeepMecheckbox();
		IFAC_Login.getInstance().Login();
		
		
	   
	}

	@Then("the user redirected to Welcome page")
	public void the_user_redirected_to_welcome_page() {
		System.out.println("the user is on the welcome page");
	   
	}

	@Then("the user clicks on the back button")
	public void the_user_clicks_on_the_back_button() {
		IFAC_Welcome_Page.getInstance().clickBack();
		
	    
	}

	@Then("the user redirected to Login Page")
	public void the_user_redirected_to_login_page() {
		System.out.println("the user is on the login page");
		
	}

	@Then("the user clicks on the login button")
	public void the_user_clicks_on_the_login_button() {
		IFAC_Login.getInstance().Login();
	}


	@When("the user select the Module from the dropdown")
	public void the_user_select_the_module_from_the_dropdown() {
	    IFAC_Welcome_Page.getInstance().selectModule();
	}

	@When("the user select  the Company from the dropdown")
	public void the_user_select_the_company_from_the_dropdown() {
		IFAC_Welcome_Page.getInstance().selectCompany();
	    
	}

	@When("the user select the location from the dropdown")
	public void the_user_select_the_location_from_the_dropdown() {
		IFAC_Welcome_Page.getInstance().selectLocation();
	   
	}

	@When("the user click on the Continue button")
	public void the_user_click_on_the_continue_button() {
		IFAC_Welcome_Page.getInstance().clickContinue();
	   
	}

	@Then("the user should be redirected to Dashboard Page")
	public void the_user_should_be_redirected_to_dashboard_page() {
		System.out.println("the user is on the Dashboard page");
		
	    
	}
	@Then("the system display the selected  location  in the Dashboard page")
	public void the_system_display_the_selected_location_in_the_dashboard_page() {
	    
		System.out.println("the system display the selected  location  in the Dashboard page");
	}





}
