package com.stepdefinitions;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.lao.Exceldata.TestDataInitializer;
import com.lao.pageobjects.IFAC_Login;
import com.lao.pageobjects.IFAC_Standard_Task;
import com.lao.pageobjects.IFAC_Welcome_Page;
import com.lao.pageobjects.IFAC_Work_Group;

import Utiliss.CommonUtilis;
import WEBDRIVER_Manager.DriverManager;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Work_Group_Step_definitions {
	
	WebDriver driver;
	TestDataInitializer dataInitializer;
    Map<String, String> testData;

    public Work_Group_Step_definitions() throws IOException {
        // Initialize test data for the sheet and retrieve data for specific test case
        dataInitializer = new TestDataInitializer("D:\\Excel\\Work_Group_Test_Data.xlsx", "Sheet1");
        testData = dataInitializer.getTestData("WGTest");
        }    
	
	
	@When("the user  click on the Hospital Master menu")
	public void the_user_click_on_the_hospital_master_menu() {
		IFAC_Work_Group.getWorkgroupinstance().selectHospitalMasters();
	   
	}
	@When("the user click on the Work Group menu")
	public void the_user_click_on_the_work_group_menu() {
		IFAC_Work_Group.getWorkgroupinstance().selectWorkGroup();
	    
	}
	@Then("the user navigate into the Work Group page")
	public void the_user_navigate_into_the_work_group_page() {
		System.out.println("the user is on the Work Group Page");
	}
	
	@When("the user clicks on the pagenation icon")
	public void the_user_clicks_on_the_pagenation_icon() {
	    IFAC_Work_Group.getWorkgroupinstance().clickPagenation();
	}
	
	@When("the user click on the Create New button")
	public void the_user_click_on_the_create_new_button() {
		IFAC_Work_Group.getWorkgroupinstance().clickCreateNew();
	}
	@Then("the user navigate into the Create Work Group Page")
	public void the_user_navigate_into_the_create_work_group_page() {
		System.out.println("the user is on the Create Work Group Page");
	    
	}
	@When("the user select the Service Dropdown")
	public void the_user_select_the_service_dropdown() {
		IFAC_Work_Group.getWorkgroupinstance().selectService();
	}
	@When("the user enters the Work Group Code {string}")
	public void the_user_enters_the_work_group_code(String enterWGCode) {
		
		String datetime = new SimpleDateFormat("ssyy").format(new Date());
		
		IFAC_Work_Group.getWorkgroupinstance().enterWorkGroupCode(testData.get(enterWGCode));
		IFAC_Work_Group.getWorkgroupinstance().enterWorkGroupCode(datetime);
	    }
	
	@When("the user enters the Work Group Description {string}")
	public void the_user_enters_the_work_group_description(String enterWGDes) {
		
		IFAC_Work_Group.getWorkgroupinstance().enterWorkGroupDescription(testData.get(enterWGDes));
	    
	}
	
	
	@When("the user click on the save button")
	public void the_user_click_on_the_save_button() {
		IFAC_Work_Group.getWorkgroupinstance().clickSaveButton();
		IFAC_Work_Group.getWorkgroupinstance().clickSaveAlertMsg();
		
		
	   
	}
	@Then("the user successfully Created the New Work Group")
	public void the_user_successfully_created_the_new_work_group() {
		
	   System.out.println("the user created the work group");
	}
	@When("the user click on the Add New button")
	public void the_user_click_on_the_add_new_button() {
		
		IFAC_Work_Group.getWorkgroupinstance().clickAddNewButton();
		
	    
	}
	@When("the user enters the New Work Group Code {string}")
	public void the_user_enters_the_new_work_group_code(String enterNewWG) {
		IFAC_Work_Group.getWorkgroupinstance().selectService();
		String datetime = new SimpleDateFormat("ssyy").format(new Date());
		IFAC_Work_Group.getWorkgroupinstance().enterNewWorkGroupCode(testData.get(enterNewWG));
		IFAC_Work_Group.getWorkgroupinstance().enterNewWorkGroupCode(testData.get(datetime));
	   
	}
	@When("the user enters the New Work Group Description {string}")
	public void the_user_enters_the_new_work_group_description(String enterNewWGDes) {
		IFAC_Work_Group.getWorkgroupinstance().enterNewWorkGroupDescription(testData.get(enterNewWGDes));
	    
	}
	
	@Then("the user allows to create a New Work Group")
	public void the_user_allows_to_create_a_new_work_group() {
		System.out.println("the user created a new Work Group");
	    
	}
	@When("the user click on the Back button")
	public void the_user_click_on_the_Back_button() {
		IFAC_Work_Group.getWorkgroupinstance().clickBackButton();
		
	    
	}
	@Then("the user navigate into Work Group page")
	public void the_user_navigate_into_work_group_page() {
		System.out.println("the user navigate into the List page");
	    
	}
	
	@Given("the user is on the Work Group page")
	public void the_user_is_on_the_work_group_page() {
		System.out.println("the user is on list page");
	}

	@When("the user clicks on the edit icon of the required Work Group {string}")
	public void the_user_clicks_on_the_edit_icon_of_the_required_Work_Group(String WGSearch) {
		IFAC_Work_Group.getWorkgroupinstance().enterWorkGroupFilter(testData.get(WGSearch));
		IFAC_Work_Group.getWorkgroupinstance().clickEditIcon();
	    
	}

	@Then("the user navigate into the Work Group edit page")
	public void the_user_navigate_into_the_work_group_edit_page() {
		System.out.println("the user is on the edit page");
	}

	@When("the user allows to edit the Work Group Description {string}")
	public void the_user_allows_to_edit_the_Work_Group_Description(String UpdateWG) {
		
		IFAC_Work_Group.getWorkgroupinstance().editWrokGroupDescription(testData.get(UpdateWG));
		
	   
	}

	@When("the user clicks on the Update button")
	public void the_user_clicks_on_the_update_button() {
		IFAC_Work_Group.getWorkgroupinstance().selectUpdateButton();
		
		
	   
	}

	@Then("the user successfully Updated  the  Work Group")
	public void the_user_successfully_updated_the_work_group() {
	    System.out.println("the user successfully updated the Work group");
	}

	@When("the user clicks on the Back button")
	public void the_user_clicks_on_the_Back_button() {
		IFAC_Work_Group.getWorkgroupinstance().clickBackButton();
		
	    
	}

	@Then("the user navigate into the Work Group Screen")
	public void the_user_navigate_into_the_work_group_screen() {
		System.out.println("the user navigate into list screen");
	   
	}


	@When("the user enter the Work Group Code {string} in search field")
	public void the_user_enter_the_work_group_code_in_search_field(String WGSearch) {
		IFAC_Work_Group.getWorkgroupinstance().enterWorkGroupFilter(testData.get(WGSearch));
	    
	}


	@When("the user clicks on the View Icon")
	public void the_user_clicks_on_the_view_icon() {
		IFAC_Work_Group.getWorkgroupinstance().clickViewIcon();
	    
	}

	@Then("the user navigate into the View  page")
	public void the_user_navigate_into_the_view_page() {
	    System.out.println("the user is on the view page");
	}

	@When("the user clicks on the Back button in the view page")
	public void the_user_clicks_on_the_Back_button_in_the_view_page() {
		IFAC_Work_Group.getWorkgroupinstance().clickBackButton();
	    
	}

	@Then("the user click on the Refresh Icon")
	public void the_user_click_on_the_refresh_icon() {
		IFAC_Work_Group.getWorkgroupinstance().clickRefreshIcon();
		
		
	   
	}

	@Then("the user click on the Export Icon")
	public void the_user_click_on_the_export_icon() {
		IFAC_Work_Group.getWorkgroupinstance().clickExportIcon();
		
	    
	}
	@When("the user clicks on the Delete button")
	public void the_user_clicks_on_the_delete_button() {
		IFAC_Work_Group.getWorkgroupinstance().clickDeleteIcon();
		IFAC_Work_Group.getWorkgroupinstance().clickDeleteConfirmMsg();
		IFAC_Work_Group.getWorkgroupinstance().clickDeleteAlertMsg();
	}
	@Then("the user deleted the required Work Group")
	public void the_user_deleted_the_required_work_group() {
	   System.out.println("the user deleted the work group");
	}

	
	@When("the user clicks the Save button with empty data")
    public void the_user_clicks_the_save_button_with_empty_data() {
		IFAC_Work_Group.getWorkgroupinstance().clickSaveButton();
	}
	
	@When("the user enter the Invalid data in Work Group Code {string} and Work Group Description{string}")
	public void the_user_enter_the_invalid_data_in_work_group_code_and_work_group_description_iwg_description(String INvalidWG , String InvalidWGDesc) {
		IFAC_Work_Group.getWorkgroupinstance().selectService();
		IFAC_Work_Group.getWorkgroupinstance().enterInvalidWorkGroupCode(testData.get(InvalidWGDesc));
		IFAC_Work_Group.getWorkgroupinstance().enterInvalidWorkGroupDescription(testData.get(InvalidWGDesc));
	    
	}
	@When("the user clicks on the save button with invalid data")
	public void the_user_clicks_on_the_save_button_with_invalid_data() {
		IFAC_Work_Group.getWorkgroupinstance().clickSaveButton();
		
		
		
	
		
		
	}



    

		
}
