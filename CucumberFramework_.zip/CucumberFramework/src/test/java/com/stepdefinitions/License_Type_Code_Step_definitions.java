package com.stepdefinitions;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import com.lao.Exceldata.TestDataInitializer;
import com.lao.pageobjects.IFAC_License_Type_Code;
import com.lao.pageobjects.IFAC_Standard_Task;
import com.lao.pageobjects.IFAC_Work_Group;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class License_Type_Code_Step_definitions {
	WebDriver driver;
	TestDataInitializer dataInitializer;
    Map<String, String> testData;
    String datetime = new SimpleDateFormat("ssyy").format(new Date());

    public License_Type_Code_Step_definitions() throws IOException {
        // Initialize test data for the sheet and retrieve data for specific test case
        dataInitializer = new TestDataInitializer("D:\\Excel\\License_Type_Code_Test_Data.xlsx", "Sheet1");
        testData = dataInitializer.getTestData("TYTest");
        }    
	
    @When("the user click on the License Type Code menu")
    public void the_user_click_on_the_license_type_code_menu() {
        IFAC_License_Type_Code.getLicenseTypeinstance().selectLicenseTypeCode();
    }
    @Then("the user navigate into the License Type Code page")
    public void the_user_navigate_into_the_license_type_code_page() {
    	System.out.println("the user navigate into the License Type Code Page");
        
    }
    @Then("the user navigate into the Create License Type Code")
    public void the_user_navigate_into_the_create_license_type_code() {
    	System.out.println("the user navigate into the Create License Type Code");

    }
    @When("the user select the Service and License Type Dropdown")
    public void the_user_select_the_service_and_license_type_dropdown() {
    	IFAC_Standard_Task.getTaskcodeinstance().selectServiceDropdown();
    	IFAC_Standard_Task.getTaskcodeinstance().selectServiceBEMS();
        IFAC_License_Type_Code.getLicenseTypeinstance().selectLicenseTypeAsset();
    }
    @When("the user enter the License Type Code {string}")
    public void the_user_enter_the_license_type_code(String enterLTCode) {
    	
    	IFAC_License_Type_Code.getLicenseTypeinstance().enterLicenseTypeCode(testData.get(enterLTCode));
    	IFAC_License_Type_Code.getLicenseTypeinstance().enterLicenseTypeCode(datetime);
    	
       
    }
    @When("the user enter the License Type Description {string}")
    public void the_user_enter_the_license_type_description(String enterLTDesc) {
    	IFAC_License_Type_Code.getLicenseTypeinstance().enterLicenseTypeDescription(testData.get(enterLTDesc));
        
    }
    @Then("the user successfully Created the New License Type Code")
    public void the_user_successfully_created_the_new_license_type_code() {
    	System.out.println("the user successfully created the New License Type Code");
    
    }
    @When("the user select the New Service and License Type Dropdown")
    public void the_user_select_the_new_service_and_license_type_dropdown() {
    	IFAC_Standard_Task.getTaskcodeinstance().selectServiceDropdown();
    	IFAC_Standard_Task.getTaskcodeinstance().selectServiceFEMS();
        IFAC_License_Type_Code.getLicenseTypeinstance().selectLicenseTypeEmployee();
      
    }
    @When("the user enter the  New License Type Code {string}")
    public void the_user_enter_the_new_license_type_code(String enterNLTCode) {
    	IFAC_License_Type_Code.getLicenseTypeinstance().enternewLicenseTypeCode(testData.get(enterNLTCode));
    	IFAC_License_Type_Code.getLicenseTypeinstance().enterLicenseTypeCode(datetime);

    }
    @When("the user enter the  New License Type Description {string}")
    public void the_user_enter_the_new_license_type_description(String enterNLTDesc) {
    	IFAC_License_Type_Code.getLicenseTypeinstance().enternewLicenseTypeDescription(testData.get(enterNLTDesc));
   
    }
    @Then("the user allows to create a New License Type Code")
    public void the_user_allows_to_create_a_new_license_type_code() {
    	System.out.println("the user allows to create a New License Type Code");
     
    }
    @Then("the user navigate into License Type Code page")
    public void the_user_navigate_into_license_type_code_page() {
    	System.out.println("the user navigate into License Type Code page");
    
    }
    
    @Given("the user is on the License Type Code page")
    public void the_user_is_on_the_license_type_code_page() {
    	System.out.println("the user is on the License Type Code page");
   
    }
    @When("the user clicks on the edit icon of the required License Type Description {string}")
    public void the_user_clicks_on_the_edit_icon_of_the_required_license_type_description(String SearchTYDesc) {
    	IFAC_License_Type_Code.getLicenseTypeinstance().SearchLicenseTypeDescription(testData.get(SearchTYDesc));
    	IFAC_Work_Group.getWorkgroupinstance().clickEditIcon();
       
    }
    @Then("the user navigate into the License type Code edit page")
    public void the_user_navigate_into_the_license_type_code_edit_page() {
    	System.out.println("the user navigate into the License Type Code edit page");
     
    }
    @When("the user allows to modify the License Type Dropdown")
    public void the_user_allows_to_modify_the_license_type_dropdown() {
    	 IFAC_License_Type_Code.getLicenseTypeinstance().selectLicenseTypeEmployee();
     
    }
    @When("the user allows to edit the License Type Description {string}")
    public void the_user_allows_to_edit_the_license_type_description(String editLTDesc) {
    	IFAC_License_Type_Code.getLicenseTypeinstance().editLicenseTypeDescription(testData.get(editLTDesc));
       
    }
    @Then("the user successfully Updated  the  License Type Code")
    public void the_user_successfully_updated_the_license_type_code() {
    	System.out.println("the user successfully updated the License Type Code");
        
    }
    @When("the user enter the License Type Code {string} in search field")
    public void the_user_enter_the_license_type_code_in_search_field(String SearchLTCode) {
    	IFAC_License_Type_Code.getLicenseTypeinstance().SearchLicenseTypeCode(testData.get(SearchLTCode));
        
    }
    @Then("the user navigate into the License Type Code Screen")
    public void the_user_navigate_into_the_license_type_code_screen() {
    	System.out.println("the user navigate into the license type Code screen");
        
    }
    @When("the user clicks on the Delete button in License Type Code referred to another record")
    public void the_user_clicks_on_the_delete_button_in_license_type_code_referred_to_another_record() {
    	IFAC_Work_Group.getWorkgroupinstance().clickDeleteIcon();
    	IFAC_Work_Group.getWorkgroupinstance().clickDeleteConfirmMsg();
    	IFAC_Work_Group.getWorkgroupinstance().clickDeleteAlertMsg();
	}
    
    @When("the user deleted the required License Type Code not Referred to another record {string}")
    public void the_user_deleted_the_required_license_type_code_not_referred_to_another_record(String SearchTYDesc) {
    	IFAC_License_Type_Code.getLicenseTypeinstance().SearchLicenseTypeDescription(testData.get(SearchTYDesc));
    	IFAC_Work_Group.getWorkgroupinstance().clickDeleteIcon();
    	IFAC_Work_Group.getWorkgroupinstance().clickDeleteConfirmMsg();
    	IFAC_Work_Group.getWorkgroupinstance().clickDeleteSuccessMsg();
        
    }
    @Then("the user navigate into the Create License Type Code Page")
    public void the_user_navigate_into_the_create_license_type_code_page() {
        System.out.println("the user navigate into the create License Type Code Page");
    }
        
    
    @When("the user enter the Invalid data in License Type Code {string} and License Type Description {string}")
    public void the_user_enter_the_invalid_data_in_license_type_code_and_license_type_description(String enterInvalidLTCode, String enterInvalidLTDesc) {
    	IFAC_License_Type_Code.getLicenseTypeinstance().enterInvalidLicenseTypeCode(testData.get(enterInvalidLTCode));
    	IFAC_License_Type_Code.getLicenseTypeinstance().enterInvalidLicenseTypeDescription(testData.get(enterInvalidLTDesc));
    	
        
    }

   
    }







