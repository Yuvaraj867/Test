package com.stepdefinitions;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import com.lao.Exceldata.TestDataInitializer;
import com.lao.pageobjects.IFAC_Standard_Task;
import com.lao.pageobjects.IFAC_User_Location;
import com.lao.pageobjects.IFAC_Work_Group;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class User_Location_Step_definitions {
	WebDriver driver;
	TestDataInitializer dataInitializer;
	Map<String, String> testData;

	public User_Location_Step_definitions() throws IOException {
		// Initialize test data for the sheet and retrieve data for specific test case
		dataInitializer = new TestDataInitializer("D:\\Excel\\User_Location_Test_Data.xlsx", "Sheet1");
		testData = dataInitializer.getTestData("ULCTest");
	}
	@When("the user click on the User Location menu")
	public void the_user_click_on_the_user_location_menu() {
		IFAC_User_Location.getUserLocationinstance().selectUserLocation();
	    
	}
	@Then("the user navigate into the User Location page")
	public void the_user_navigate_into_the_user_location_page() {
		System.out.println("the user navigate into the User Location Page");
	   
	}
	@Then("the user navigate into the Create User Location Page")
	public void the_user_navigate_into_the_create_user_location_page() {
		System.out.println("the user navigate into the Create User Location Page");
	    
	}
	@When("the user enters the Location Code {string}")
	public void the_user_enters_the_location_code(String enterLCode) {
		String datetime = new SimpleDateFormat("ssyy").format(new Date());
		IFAC_User_Location.getUserLocationinstance().enterLocationCode(testData.get(enterLCode));
		IFAC_User_Location.getUserLocationinstance().enterLocationCode(datetime);
	}
	@When("the user enters the Location Name {string}")
	public void the_user_enters_the_location_name(String enterLNmae) {
	   IFAC_User_Location.getUserLocationinstance().enterLocationName(testData.get(enterLNmae));
	}
	@When("the user select the Department Description {string} from lookup")
	public void the_user_select_the_department_description_from_lookup(String enterDesc) {
		IFAC_User_Location.getUserLocationinstance().selectDepartmentDescription(testData.get(enterDesc));
	    
	}
	@When("the user select the effective from Date")
	public void the_user_select_the_effective_from_date() {
		IFAC_Standard_Task.getTaskcodeinstance().clickDatepicker();
		IFAC_Standard_Task.getTaskcodeinstance().selectDate();
	    
	}
	@Then("the user successfully Created the New User Location")
	public void the_user_successfully_created_the_new_user_location() {
	    System.out.println("the user successfully created the New User Location");
	}
	@When("the user enters the New Location Code {string}")
	public void the_user_enters_the_new_location_code(String enterNLcode) {
		String datetime = new SimpleDateFormat("ssyy").format(new Date());
		IFAC_User_Location.getUserLocationinstance().enterNewLocationCode(testData.get(enterNLcode));
	    IFAC_User_Location.getUserLocationinstance().enterNewLocationCode(datetime);
	}
	@When("the user enters the New  Location Name {string}")
	public void the_user_enters_the_new_location_name(String enterNLName) {
		IFAC_User_Location.getUserLocationinstance().enterNewLocationName(testData.get(enterNLName));
	    
	}
	@Then("the user allows to create a New User Location")
	public void the_user_allows_to_create_a_new_user_location() {
		System.out.println("the user allows to create a New user Location");
	    
	}
	@Then("the user navigate into User Location page")
	public void the_user_navigate_into_user_location_page() {
		System.out.println("the user navigate into User Location page");
	    
	}
	
	@Given("the user is on the User Location page")
	public void the_user_is_on_the_user_location_page() {
		System.out.println("the user is on the User Location page");
	    
	}
	@When("the user clicks on the edit icon of the required User Location {string}")
	public void the_user_clicks_on_the_edit_icon_of_the_required_user_location(String searchULcode) {
		IFAC_User_Location.getUserLocationinstance().enterUserLocationCode(testData.get(searchULcode));
		IFAC_Work_Group.getWorkgroupinstance().clickEditIcon();
	    
	}
	@Then("the user navigate into the User Location edit page")
	public void the_user_navigate_into_the_user_location_edit_page() {
		System.out.println("the user navigate into the User Location edit page");
	    
	}
	@When("the user allows to modify the status as Inactive")
	public void the_user_allows_to_modify_the_status_as_inactive() {
		IFAC_User_Location.getUserLocationinstance().selectStatusInActive();
	    
	}
	@When("the user edit the Location Name {string}")
	public void the_user_edit_the_location_name(String editLName) {
		IFAC_User_Location.getUserLocationinstance().editLocationName(testData.get(editLName));
		
	    
	}
	@When("the user edit the Department Description {string}")
	public void the_user_edit_the_department_description(String editdesc) {
		IFAC_User_Location.getUserLocationinstance().editDepartmentDescription(testData.get(editdesc));
	    
	}
	@Then("the user successfully Updated  the  User Location")
	public void the_user_successfully_updated_the_user_location() {
		System.out.println("the user successfully updated the User Location");
	   
	}
	@Then("the user navigate into the User Location Screen")
	public void the_user_navigate_into_the_user_location_screen() {
		System.out.println("the user navigate into the User Location Screen");
	   
	}

	@When("the user enter the Location Code {string} in search field")
	public void the_user_enter_the_location_code_in_search_field(String searchULCode) {
		IFAC_User_Location.getUserLocationinstance().enterUserLocationCode(testData.get(searchULCode));
	   
	}
	
	@When("the user deleted the required User Location")
	public void the_user_deleted_the_required_user_location() {
		IFAC_Work_Group.getWorkgroupinstance().clickDeleteIcon();
		IFAC_Work_Group.getWorkgroupinstance().clickDeleteConfirmMsg();
		IFAC_Work_Group.getWorkgroupinstance().clickDeleteAlertMsg();
	   
	}
	@When("the user enter the Invalid data in Location Code {string} and Location Name {string}")
	public void the_user_enter_the_invalid_data_in_location_code_and_location_name(String enterILCode, String enterILName) {
	   IFAC_User_Location.getUserLocationinstance().enterInvalidLocationCode(testData.get(enterILCode));
	   IFAC_User_Location.getUserLocationinstance().enterInvalidLocationName(testData.get(enterILName));
	}
	@Then("the user navigate into the Dashboard page")
	public void the_user_navigate_into_the_dashboard_page() {
		System.out.println("the user navigate into the Dashboard page");
	    
	}



}
