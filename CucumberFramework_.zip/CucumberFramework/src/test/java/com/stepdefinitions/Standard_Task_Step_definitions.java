package com.stepdefinitions;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.lao.Exceldata.TestDataInitializer;
import com.lao.pageobjects.IFAC_Standard_Task;
import com.lao.pageobjects.IFAC_Work_Group;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Standard_Task_Step_definitions {
	static Logger logger =Logger.getLogger(Common_Step_definition.class);
	WebDriver driver;
	TestDataInitializer dataInitializer;
    Map<String, String> testData;

    public Standard_Task_Step_definitions() throws IOException {
        // Initialize test data for the sheet and retrieve data for specific test case
    	  dataInitializer = new TestDataInitializer("D:\\Excel\\Standard_Task_Test_Data.xlsx", "Sheet1");
          testData = dataInitializer.getTestData("TCTest");
          }    
    
    @When("the user click on the Standard Task Details menu")
    public void the_user_click_on_the_standard_task_details_menu() {
    	IFAC_Standard_Task.getTaskcodeinstance().selectStandardTaskDetail();
    }
    @Then("the user navigate into the Standard Task Details page")
    public void the_user_navigate_into_the_standard_task_details_page() {
    	System.out.println("the user navigate into Task Details page");
        
    }
   
    @Then("the user navigate into the Create New Task Page")
    public void the_user_navigate_into_the_create_new_task_page() {
    	System.out.println("the user navigate into the Create New Task Page");
    	
       
    }
    @When("the user select the Service, Work Group  from the Dropdown")
    public void the_user_select_the_Service_Work_group_from_the_Dropdown() {
      IFAC_Standard_Task.getTaskcodeinstance().selectServiceDropdown();
      IFAC_Standard_Task.getTaskcodeinstance().selectServiceFEMS();
      IFAC_Standard_Task.getTaskcodeinstance().clickWorkGroup();
      IFAC_Standard_Task.getTaskcodeinstance().selectWorkGroupDropdown();
      
       
    }
    @Then("the user enter in the Task Code {string} and Task Code Description  field {string}")
    public void the_user_enter_in_the_task_code_tc_and_task_code_description_field(String TaskCode , String TCdesc)
    {   
    	String datetime = new SimpleDateFormat("ssyy").format(new Date());
        IFAC_Standard_Task.getTaskcodeinstance().enterTaskCode(testData.get(TaskCode));
        IFAC_Standard_Task.getTaskcodeinstance().enterTaskCode(datetime);
    	IFAC_Standard_Task.getTaskcodeinstance().enterTaskDescription(testData.get(TCdesc));
    	
     
    }
    @Then("the user select the Status Dropdown as Active")
    public void the_user_select_the_status_dropdown_as_active() {
    	
    //	IFAC_Standard_Task.getTaskcodeinstance().selectStatusActive();
       
    }
    @Then("the user select the Effective From Date from the calendar")
    public void the_user_select_the_effective_from_date_from_the_calendar() {
    	//IFAC_Standard_Task.getTaskcodeinstance().clickDatepicker();
    	//IFAC_Standard_Task.getTaskcodeinstance().selectDate();
        
    }
    @Then("the user enter the Work Instruction Field {string}")
    public void the_user_enter_the_Work_Instruction_Field(String Work_Ins) {
    	IFAC_Standard_Task.getTaskcodeinstance().enterWorkInstruction(testData.get(Work_Ins));
       
    }
   
    @Then("the user successfully Created the New Task")
    public void the_user_successfully_created_the_new_task() {
    	System.out.println("the user created the  task");
       
    }
    @When("the user enter the new Task Code {string} and new Task Description {string}")
    public void the_user_enter_the_new_task_code_and_new_task_description(String TCN, String TCCode) {
    	String datetime = new SimpleDateFormat("ssyy").format(new Date());
        IFAC_Standard_Task.getTaskcodeinstance().enterTaskCode(testData.get(TCN));
        IFAC_Standard_Task.getTaskcodeinstance().enterTaskCode(datetime);
    	IFAC_Standard_Task.getTaskcodeinstance().enterTaskDescription(testData.get(TCCode));
       
    }
   
   
    @When("the user select the Status Dropdown as InActive")
    public void the_user_select_the_status_dropdown_as_in_active() {
    //	IFAC_Standard_Task.getTaskcodeinstance().selectStatusInActive();
        
    }
    
    @Then("the user allows to create a New  Task Code")
    public void the_user_allows_to_create_a_new_task_code() {
    	System.out.println("the user allows to create a New  Task Code");
       
    }
    @Then("the user navigate into Standard Task Details page")
    public void the_user_navigate_into_standard_task_details_page() {
        System.out.println("the user navigate into standard task details page");
    }
    @Given("the user is on the Standard Task Details page")
    public void the_user_is_on_the_standard_task_details_page() {
        
    }
   
    @When("the user enter the Work Group Code {string} in search field of Standard Task Details")
    public void the_user_enter_the_work_group_code_in_search_field_of_standard_task_details(String WGSearch) {
    	IFAC_Standard_Task.getTaskcodeinstance().enterWGSearchFilter(testData.get(WGSearch));
    	
    }
    @When("the user modify the Service, Work Group  from the Dropdown")
    public void the_user_modify_the_service_work_group_from_the_dropdown() {
    	IFAC_Work_Group.getWorkgroupinstance().clickEditIcon();
    	//IFAC_Standard_Task.getTaskcodeinstance().selectServiceDropdown();
      //  IFAC_Standard_Task.getTaskcodeinstance().selectServiceBEMS();
       // IFAC_Standard_Task.getTaskcodeinstance().clickWorkGroup();
      //  IFAC_Standard_Task.getTaskcodeinstance().selectWorkGroupDropdown();
    	
        
    }            
    @Then("the user edit in the  Task Code Description {string} field")
    public void the_user_edit_in_the_task_code_description_field(String TtC_des) {
    	IFAC_Standard_Task.getTaskcodeinstance().editTaskDescription(testData.get(TtC_des));
       
    }
    @Then("the user select the Status Dropdown")
    public void the_user_select_the_status_dropdown() {
    	IFAC_Standard_Task.getTaskcodeinstance().selectStatusInActive();
    }
   
    @Then("the user successfully Updated  the  Standard Task Details")
    public void the_user_successfully_updated_the_standard_task_details() {
    	System.out.println("the user successfully updated the Standard Task Details");
        
    }
    @Then("the user navigate into the Standard Task Details Screen")
    public void the_user_navigate_into_the_standard_task_details_screen() {
    	System.out.println("the user navigate into the standard task details screen");
        
    }
    
   
    @When("the user select the service from the dropdown")
    public void the_user_select_the_service_from_the_dropdown() {
    	IFAC_Standard_Task.getTaskcodeinstance().selectServiceDropdown();
        IFAC_Standard_Task.getTaskcodeinstance().selectServiceBEMS();
    	
        
    }
    @When("the user clicks on the Delete button in Task Code")
    public void the_user_clicks_on_the_delete_button_in_task_code() {
    	IFAC_Work_Group.getWorkgroupinstance().clickDeleteIcon();
    	IFAC_Work_Group.getWorkgroupinstance().clickDeleteConfirmMsg();
    	IFAC_Work_Group.getWorkgroupinstance().clickDeleteAlertMsg();
        
    }
    @When("the user deleted the required  Standard Task Details")
    public void the_user_deleted_the_required_standard_task_details() {
        
    }
    @When("the user enter the Invalid data in Task Code {string} and Task Description {string}")
    public void the_user_enter_the_invalid_data_in_task_code_and_task_description(String ITCo, String ICODES) {
        
    	
    	IFAC_Standard_Task.getTaskcodeinstance().enterInvalidTaskCode(testData.get(ITCo));
    	IFAC_Standard_Task.getTaskcodeinstance().enterInvalidTaskDescription(testData.get(ICODES));
       
    }
}
