package com.stepdefinitions;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.lao.Exceldata.TestDataInitializer;
import com.lao.pageobjects.IFAC_User_Department;
import com.lao.pageobjects.IFAC_Work_Group;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class User_Department_Step_definitions {

	static Logger logger =Logger.getLogger(Common_Step_definition.class);
	WebDriver driver;
	TestDataInitializer dataInitializer;
    Map<String, String> testData;

    public User_Department_Step_definitions() throws IOException {
        // Initialize test data for the sheet and retrieve data for specific test case
        dataInitializer = new TestDataInitializer("D:\\Excel\\User_Department_Test_Data.xlsx", "Sheet1");
        testData = dataInitializer.getTestData("DepTest");
        }    
    @When("the user click on the User Department menu")
    public void the_user_click_on_the_user_department_menu() {
    	
    	IFAC_User_Department.getUserdepinstance().selectUserDepartment();
        
    }
    @Then("the user navigate into the User Department page")
    public void the_user_navigate_into_the_user_department_page() {
    	System.out.println("the user navigate into the User Department page");
        
    }
    @Then("the user navigate into the Create User Department Page")
    public void the_user_navigate_into_the_create_user_department_page() {
    	System.out.println(" the user navigate into the Created User Department Page");
       
    }
    @Then("the user enters the Department Code {string}")
    public void the_user_enters_the_department_code(String enterDC) {
    	String datetime = new SimpleDateFormat("ssyy").format(new Date());
	    IFAC_User_Department.getUserdepinstance().enterDepCode(testData.get(enterDC));
	    IFAC_User_Department.getUserdepinstance().enterDepCode(datetime);
       
    }
    @Then("the user enters the Department Description {string}")
    public void the_user_enters_the_department_description(String enterDesc) {
    	IFAC_User_Department.getUserdepinstance().enterDepDesc(testData.get(enterDesc));
        
    }
    @Then("the user successfully Created the New User Department")
    public void the_user_successfully_created_the_new_user_department() {
    	System.out.println("the user successfully created the New user Department");
        
    }
    @When("the user enters the New Department Code {string}")
    public void the_user_enters_the_new_department_code(String enternewDc) {
    	String datetime = new SimpleDateFormat("ssyy").format(new Date());
    	IFAC_User_Department.getUserdepinstance().enterNewDepCode(testData.get(enternewDc));
    	IFAC_User_Department.getUserdepinstance().enterNewDepCode(datetime);
       
    }
    @When("the user enters the New Department Description {string}")
    public void the_user_enters_the_new_department_description(String enternewDesc) {
    	IFAC_User_Department.getUserdepinstance().enterNewDepDesc(testData.get(enternewDesc));
        
    }
   
    @Then("the user navigate into User Department page")
    public void the_user_navigate_into_user_department_page() {
    	System.out.println("the user navigate into the User Department page");
        
    }
    
    @When("the user clicks on the edit icon of the required User Department {string}")
    public void the_user_clicks_on_the_edit_icon_of_the_required_user_department(String SearchUser) {
     IFAC_User_Department.getUserdepinstance().enterDep_Search_Filter("D01");
     IFAC_Work_Group.getWorkgroupinstance().clickEditIcon();
    }
    @Then("the user navigate into the User Department edit page")
    public void the_user_navigate_into_the_user_department_edit_page() {
    	System.out.println("the user navigate into the User Department edit page");
       
    }
    @When("the user allows to edit the Department Description {string}")
    public void the_user_allows_to_edit_the_department_description(String editDepdesc) {
    	IFAC_User_Department.getUserdepinstance().editDepDesc(testData.get(editDepdesc));
    	
    }
   
  
    @When("the user enter the Department Code {string} in search field")
    public void the_user_enter_the_department_code_in_search_field(String enterSearch) {
    	IFAC_User_Department.getUserdepinstance().enterDep_Search_Filter("D01");
        
    }
   
    @When("the user deleted the required User Department")
    public void the_user_deleted_the_required_user_department() {
    	IFAC_Work_Group.getWorkgroupinstance().clickDeleteIcon();
    	IFAC_Work_Group.getWorkgroupinstance().clickDeleteConfirmMsg();
    	IFAC_Work_Group.getWorkgroupinstance().clickDeleteAlertMsg();    	
    	System.out.println("the user delete the required user department");
        
    }
    @When("the user enter the Invalid data in Department Code {string} and Department Description {string}")
    public void the_user_enter_the_invalid_data_in_department_code_and_department_description(String enterInvalidCode , String enterInvalidDesc ) {
    	IFAC_User_Department.getUserdepinstance().enterInvalidDepCode(testData.get(enterInvalidCode));
    	IFAC_User_Department.getUserdepinstance().enterInvalidDepDesc(testData.get(enterInvalidDesc));
        
    }







    
}
