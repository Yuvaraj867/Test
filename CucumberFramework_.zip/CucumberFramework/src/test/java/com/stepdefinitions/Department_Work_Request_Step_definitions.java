package com.stepdefinitions;

import java.io.IOException;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import com.lao.Exceldata.TestDataInitializer;
import com.lao.pageobjects.IFAC_Department_Work_Request;
import com.lao.pageobjects.IFAC_Standard_Task;
import com.lao.pageobjects.IFAC_Work_Group;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Department_Work_Request_Step_definitions {
	WebDriver driver;
	TestDataInitializer dataInitializer;
	Map<String, String> testData;

	public Department_Work_Request_Step_definitions() throws IOException {
		// Initialize test data for the sheet and retrieve data for specific test case
		dataInitializer = new TestDataInitializer("D:\\Excel\\Department_Work_Request_Test_Data.xlsx", "Sheet1");
		testData = dataInitializer.getTestData("DWRTest");
	}


	@When("the user  click on the Maintenance menu")
	public void the_user_click_on_the_maintenance_menu() {
		IFAC_Department_Work_Request.getWorkRequestinstance().selectMaintenance();
	    
	}
	@And("the user click on the Department Work Request menu")
	public void the_user_click_on_the_department_work_request_menu() {
		IFAC_Department_Work_Request.getWorkRequestinstance().selectDepartmentWorkRequest();
	   
	}
	@Then("the user navigate into the Department Work Request page")
	public void the_user_navigate_into_the_department_work_request_page() {
	    System.out.println("the user navigate into the Department Work Request page");
	}
	@Then("the user navigate into the Create Department Work Request Page")
	public void the_user_navigate_into_the_create_department_work_request_page() {
		System.out.println("the user navigate into the Create Department Work Request Page");
	    
	}
	@When("the user enter the Requestor {string}, Designation {string} and Contact no. {string}")
	public void the_user_enter_the_requestor_designation_and_contact_no(String enterReq, String enterDesign, String enterContact) {
	    IFAC_Department_Work_Request.getWorkRequestinstance().enterRequestor(testData.get(enterReq));
	    IFAC_Department_Work_Request.getWorkRequestinstance().enterDesignation(testData.get(enterDesign));
	    IFAC_Department_Work_Request.getWorkRequestinstance().enterContactNo(testData.get(enterContact));
	}
	@When("the user selects the Asset No {string} in the lookup")
	public void the_user_selects_the_asset_no_in_the_lookup(String enterasset) {
		IFAC_Department_Work_Request.getWorkRequestinstance().selectAssetNo(testData.get(enterasset));
	    
	}
	@When("the user select the Category and Type from the dropdown")
	public void the_user_select_the_category_and_type_from_the_dropdown() {
		IFAC_Department_Work_Request.getWorkRequestinstance().selectCategory();
	    
	}
	@When("the user enter the Request Details {string}")
	public void the_user_enter_the_request_details(String enterreq) {
		IFAC_Department_Work_Request.getWorkRequestinstance().enterRequestDetails(testData.get(enterreq));
	    
	}
	@When("the user enter the new  Requestor {string}, Designation {string} and Contact no. {string}")
	public void the_user_enter_the_new_requestor_designation_and_contact_no(String enterNReq, String enterNDesgn, String enterNContact) {
		IFAC_Department_Work_Request.getWorkRequestinstance().enternewRequestor(testData.get(enterNReq));
		IFAC_Department_Work_Request.getWorkRequestinstance().enternewDesignation(testData.get(enterNDesgn));
		IFAC_Department_Work_Request.getWorkRequestinstance().enternewContactNo(testData.get(enterNContact));
	    
	}
	@When("the user selects the new Asset No {string} in the lookup")
	public void the_user_selects_the_new_asset_no_in_the_lookup(String enterNAsset) {
	    IFAC_Department_Work_Request.getWorkRequestinstance().selectnewAssetNo(testData.get(enterNAsset));
	}
	@When("the user select the new  Category and Type from the dropdown")
	public void the_user_select_the_new_category_and_type_from_the_dropdown() {
		IFAC_Department_Work_Request.getWorkRequestinstance().selectCategory();
		IFAC_Department_Work_Request.getWorkRequestinstance().selectType();
	    
	}
	
	@Then("the user navigate into Department Work Request page")
	public void the_user_navigate_into_department_work_request_page() {
	    System.out.println("the user navigate into Department Work Request Page");
	}

	@When("the user clicks on the edit icon of the required Work Request {string}")
	public void the_user_clicks_on_the_edit_icon_of_the_required_work_request(String enterWRN) {
		IFAC_Department_Work_Request.getWorkRequestinstance().enterWorkRequestNo(testData.get(enterWRN));
		IFAC_Work_Group.getWorkgroupinstance().clickEditIcon();
	    
	}
	@Then("the user navigate into the Department Work Request edit page")
	public void the_user_navigate_into_the_department_work_request_edit_page() {
		System.out.println("the user navigate into the department work request edit page");
	    
	}
	@When("the user edit the   Requestor {string}, Designation {string} and Contact no. {string}")
	public void the_user_edit_the_requestor_designation_and_contact_no(String ereq, String edes, String econ) {
		IFAC_Department_Work_Request.getWorkRequestinstance().editRequestor(testData.get(ereq));
		IFAC_Department_Work_Request.getWorkRequestinstance().editDesignation(testData.get(edes));
		IFAC_Department_Work_Request.getWorkRequestinstance().editContactNo(testData.get(econ));
	    
	}
	@When("the user modify the   Category and Type from the dropdown")
	public void the_user_modify_the_category_and_type_from_the_dropdown() {
		IFAC_Department_Work_Request.getWorkRequestinstance().selectCategory();
		IFAC_Department_Work_Request.getWorkRequestinstance().selectType();
	   
	}
	@When("the user edit the Request Details {string}")
	public void the_user_edit_the_request_details(String erqD) {
		IFAC_Department_Work_Request.getWorkRequestinstance().editRequestDetails(testData.get(erqD));
	    
	}
	@Then("the user successfully Updated  the  Department Work Request")
	public void the_user_successfully_updated_the_department_work_request() {
		System.out.println("the user successfully updated the Department Work Request");
	    
	}
	@Then("the user navigate into the  Department Work Request Screen")
	public void the_user_navigate_into_the_department_work_request_screen() {
		System.out.println("the user navigate into the Department Work Request Screen");
	    
	}
	@When("the user enter the Work Request No {string} in search field of Work Request")
	public void the_user_enter_the_work_request_no_in_search_field_of_work_request(String enterWRN) {
		IFAC_Department_Work_Request.getWorkRequestinstance().enterWorkRequestNo(testData.get(enterWRN));
	    
	}
	@When("the user clicks on the Delete button in Department Work Request referred to another record")
	public void the_user_clicks_on_the_delete_button_in_department_work_request_referred_to_another_record() {
		//IFAC_Work_Group.getWorkgroupinstance().clickDeleteIcon();
    	//IFAC_Work_Group.getWorkgroupinstance().clickDeleteConfirmMsg();
    	//IFAC_Work_Group.getWorkgroupinstance().clickDeleteAlertMsg();
	}
	@When("the user deleted the required Department Work Request not Referred to another record {string}")
	public void the_user_deleted_the_required_department_work_request_not_referred_to_another_record(String searchdesc) {
		IFAC_Department_Work_Request.getWorkRequestinstance().enterWorkRequestDesc(testData.get(searchdesc));
		IFAC_Work_Group.getWorkgroupinstance().clickDeleteIcon();
    	IFAC_Work_Group.getWorkgroupinstance().clickDeleteConfirmMsg();
    	IFAC_Work_Group.getWorkgroupinstance().clickDeleteSuccessMsg();
    	//IFAC_Work_Group.getWorkgroupinstance().clickDeleteAlertMsg();
	}

	
	
	
	
	@When("the user select the  FEMS service from the dropdown")
	public void the_user_select_the_fems_service_from_the_dropdown() {
		IFAC_Standard_Task.getTaskcodeinstance().selectServiceDropdown();
        IFAC_Standard_Task.getTaskcodeinstance().selectServiceFEMS();
	}

	@When("the user enter the Invalid data in Requestor {string}, Designation {string} , Contact no. {string} and Request Details {string}")
	public void the_user_enter_the_invalid_data_in_requestor_designation_contact_no_and_request_details(String Ireq, String Ides, String Icon, String IRDetails) {
	    IFAC_Department_Work_Request.getWorkRequestinstance().enterInvalidRequestor(testData.get(Ireq));
	    IFAC_Department_Work_Request.getWorkRequestinstance().enterInvalidDesignation(testData.get(Ides));
	    IFAC_Department_Work_Request.getWorkRequestinstance().enterInvalidContactNo(testData.get(Icon));
	    IFAC_Department_Work_Request.getWorkRequestinstance().enterInvalidRequestDetails(testData.get(IRDetails));
	}




}
