package com.stepdefinitions;

import java.io.IOException;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import com.lao.Exceldata.TestDataInitializer;
import com.lao.pageobjects.IFAC_Maintenance_Year_Details;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Maintenance_Year_Step_definition {
	WebDriver driver;
	TestDataInitializer dataInitializer;
    Map<String, String> testData;

    public Maintenance_Year_Step_definition() throws IOException {
        // Initialize test data for the sheet and retrieve data for specific test case
        dataInitializer = new TestDataInitializer("D:\\Excel\\Maintenance_Year_Details_Test_Data.xlsx", "Sheet1");
        testData = dataInitializer.getTestData("MYTest");
        }    
	@When("the user click on the Maintanence Year Details menu")
	public void the_user_click_on_the_maintanence_year_details_menu() {
	    IFAC_Maintenance_Year_Details.getInstance().selectMaintenanceYearDetail();
	}
	@Then("the user sucessfully navigate into the Maintanence Year Details Screen")
	public void the_user_sucessfully_navigate_into_the_maintanence_year_details_screen() {
	    
	}
	@Then("the user click on the pagesize dropdown")
	public void the_user_click_on_the_pagesize_dropdown() {
		//IFAC_Maintenance_Year_Details.getInstance().ClickPageSize();
		//IFAC_Maintenance_Year_Details.getInstance().ClickPageSizeDropdown();
	}
	
	
	@When("the user enter the Required Year {string} in Column Field")
	public void the_user_enter_the_required_year_in_column_field(String enterYear) {
		IFAC_Maintenance_Year_Details.getInstance().EnterYear(testData.get(enterYear));
	   
	}
	
	@Then("the user sort the grid according to the given Year")
	public void the_user_sort_the_grid_according_to_the_given_year() {
		System.out.println("the user sort the grid according to the given Year");
	}
	
	@Then("the user Export the Maintanence Year Details grid")
	public void the_user_export_the_maintanence_year_details_grid() {
		System.out.println("the user export the Maintanence Year Details grid");
	  
	}
	
	@And("the user selects the Page Size dropdown")
	public void the_user_selects_the_page_size_dropdown() {
		IFAC_Maintenance_Year_Details.getInstance().ClickPageSize();
		
	    
	}
	@When("the user enter Invalid data in Year {string} in Column Field")
	public void the_user_enter_invalid_data_in_year_in_column_field(String enterInvalidYear) {
		IFAC_Maintenance_Year_Details.getInstance().EnterInvalidYear(testData.get(enterInvalidYear));
	  
	}
	
	
	
	@When("the user clicks on the Dashboard icon")
	public void the_user_clicks_on_the_dashboard_icon() {
		IFAC_Maintenance_Year_Details.getInstance().ClickHome();
	    
}
	
}
