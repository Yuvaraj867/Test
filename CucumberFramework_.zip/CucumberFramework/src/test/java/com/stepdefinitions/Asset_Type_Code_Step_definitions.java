package com.stepdefinitions;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import com.lao.Exceldata.TestDataInitializer;
import com.lao.pageobjects.IFAC_Asset_Type_Code;
import com.lao.pageobjects.IFAC_Standard_Task;
import com.lao.pageobjects.IFAC_Work_Group;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.opentelemetry.exporter.logging.SystemOutLogRecordExporter;

public class Asset_Type_Code_Step_definitions {
	WebDriver driver;
	TestDataInitializer dataInitializer;
	Map<String, String> testData;

	public Asset_Type_Code_Step_definitions() throws IOException {
		// Initialize test data for the sheet and retrieve data for specific test case
		dataInitializer = new TestDataInitializer("D:\\Excel\\Asset_Type_Code_Test_Data.xlsx", "Sheet1");
		testData = dataInitializer.getTestData("TYTest");
	}

	
	@When("the user click on the Asset Type Code menu")
	public void the_user_click_on_the_asset_type_code_menu() {
	    IFAC_Asset_Type_Code.getAssetTypeCodeinstance().selectAssetTypeCode();
	}
	@Then("the user navigate into the Asset Type Code page")
	public void the_user_navigate_into_the_asset_type_code_page() {
	   System.out.println("the user navigate into the Asset Type Code Page");
	}
	@Then("the user navigate into the Create Type Code")
	public void the_user_navigate_into_the_create_type_code() {
	   System.out.println("the user navigate into the create type code page");
	}
	@When("the user select the Service and Asset Classification Dropdown")
	public void the_user_select_the_service_and_asset_classification_dropdown() {
		IFAC_Standard_Task.getTaskcodeinstance().selectServiceDropdown();
		IFAC_Standard_Task.getTaskcodeinstance().selectServiceBEMS();
		IFAC_Asset_Type_Code.getAssetTypeCodeinstance().selectAssetClassification();
	   
	}
	@When("the user select the Asset Category in lookup {string}")
	public void the_user_select_the_asset_category_in_lookup(String enterAssetCategory) {
		IFAC_Asset_Type_Code.getAssetTypeCodeinstance().selectAssetCategory(testData.get(enterAssetCategory));
		
	   
	}
	@When("the user enter the Asset Type Code {string} and Type Code Description {string}")
	public void the_user_enter_the_asset_type_code_and_type_code_description(String AssetTypeCode, String TypeCodeDescription) {
		String datetime = new SimpleDateFormat("ssyy").format(new Date());
		IFAC_Asset_Type_Code.getAssetTypeCodeinstance().enterTypeCode(testData.get(AssetTypeCode));
		IFAC_Asset_Type_Code.getAssetTypeCodeinstance().enterTypeCode(datetime);
		IFAC_Asset_Type_Code.getAssetTypeCodeinstance().enterTypeCodeDescription(testData.get(TypeCodeDescription));
	    
	}
	@Then("the user successfully Created the New Type Code")
	public void the_user_successfully_created_the_new_type_code() {
		System.out.println("the user successfully created the new type code");
	    
	}
	@When("the user select the  New Asset Category in lookup {string}")
	public void the_user_select_the_new_asset_category_in_lookup(String NAssetCategory) {
		IFAC_Asset_Type_Code.getAssetTypeCodeinstance().selectNewAssetCategory(testData.get(NAssetCategory));
	   
	}
	@When("the user enter the New  Asset Type Code {string} and  New Type Code Description {string}")
	public void the_user_enter_the_new_asset_type_code_and_new_type_code_description(String NTypeCode, String NTypeCodeDescription) {
		String datetime = new SimpleDateFormat("ssyy").format(new Date());
	   IFAC_Asset_Type_Code.getAssetTypeCodeinstance().enterNewTypeCode(testData.get(NTypeCode));
	   IFAC_Asset_Type_Code.getAssetTypeCodeinstance().enterNewTypeCode(datetime);
	   IFAC_Asset_Type_Code.getAssetTypeCodeinstance().enterNewTypeCodeDescription(testData.get(NTypeCodeDescription));
	}
	@Then("the user allows to create a New Type Code")
	public void the_user_allows_to_create_a_new_type_code() {
	   System.out.println("the user allows to create a New Type Code");
	}
	@Then("the user navigate into Asset Type Code page")
	public void the_user_navigate_into_asset_type_code_page() {
		System.out.println("the user navigate into asset type code page");
	    
	}
	@Given("the user is on the Asset Type Code page")
	public void the_user_is_on_the_asset_type_code_page() {
		System.out.println("the user is on the Asset Type Code page");
	    
	}
	@When("the user clicks on the edit icon of the required Type Code {string}")
	public void the_user_clicks_on_the_edit_icon_of_the_required_type_code(String SearchTypeCode) {
		IFAC_Asset_Type_Code.getAssetTypeCodeinstance().enterTypeCodeFilter(testData.get(SearchTypeCode));
		IFAC_Work_Group.getWorkgroupinstance().clickEditIcon();
	    
	}
	@Then("the user navigate into the Asset type Code edit page")
	public void the_user_navigate_into_the_asset_type_code_edit_page() {
	    System.out.println("the user navigate into the Asset type Code edit page");
	}
	@When("the user allows to edit the Type Code {string} and Type Code Description {string}")
	public void the_user_allows_to_edit_the_type_code_and_type_code_description(String ETypeCode, String ETypeCodeDescription) {
	   IFAC_Asset_Type_Code.getAssetTypeCodeinstance().editTypeCode(testData.get(ETypeCode));
	   IFAC_Asset_Type_Code.getAssetTypeCodeinstance().editTypeCodeDescription(testData.get(ETypeCodeDescription));
	}
	@Then("the user successfully Updated  the  Asset Type Code")
	public void the_user_successfully_updated_the_asset_type_code() {
		System.out.println("the user successfully updated the Asset Type Code");
	    
	}
	@When("the user enter the Asset Type Code {string} in search field")
	public void the_user_enter_the_asset_type_code_in_search_field(String SearchTypeCode) {
		IFAC_Asset_Type_Code.getAssetTypeCodeinstance().enterTypeCodeFilter(testData.get(SearchTypeCode));
	   
	}
	@Then("the user navigate into the Asset Type Code Screen")
	public void the_user_navigate_into_the_asset_type_code_screen() {
		System.out.println("the user navigate into the Asset Type Code screen");
	    
	}
	@When("the user deleted the required Asset Type Code")
	public void the_user_deleted_the_required_asset_type_code() {
		//IFAC_Work_Group.getWorkgroupinstance().clickDeleteIcon();
    	//IFAC_Work_Group.getWorkgroupinstance().clickDeleteConfirmMsg();
    	//IFAC_Work_Group.getWorkgroupinstance().clickDeleteAlertMsg();
		
	    
	}
	@Then("the user navigate into the Create Asset Type Code Page")
	public void the_user_navigate_into_the_create_asset_type_code_page() {
	    System.out.println("the user navigate into the Create Asset Type Code Page");
	}
	@When("the user enter the Invalid data in Type Code {string} and Work Group Description {string}")
	public void the_user_enter_the_invalid_data_in_type_code_and_work_group_description(String ITypeCode, String ITypeDescription) {
	    IFAC_Asset_Type_Code.getAssetTypeCodeinstance().enterInvalidTypeCode(testData.get(ITypeCode));
	    IFAC_Asset_Type_Code.getAssetTypeCodeinstance().enterInvalidTypeCodeDescription(testData.get(ITypeDescription));
	}
	



	

}
