package com.lao.runnerclass;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;

@RunWith(Cucumber.class)
@io.cucumber.junit.CucumberOptions(features=  "src/test/resources/Featurefiles/User_Location.feature" , 
glue = {"com.stepdefinitions"},
dryRun=false,
monochrome=true,

plugin = {"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:" ,"html:report/cucumber-report.html","junit:report/cucumber.xml", "json:report/jsonreport.json"},
tags= "@User_Location_page"																					                                     /*publish=true*/
)


public class Runnerclass {
	

}
