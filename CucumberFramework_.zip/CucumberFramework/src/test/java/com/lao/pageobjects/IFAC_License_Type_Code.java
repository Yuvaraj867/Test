package com.lao.pageobjects;

import org.openqa.selenium.By;

import Utiliss.CommonUtilis;
import WEBDRIVER_Manager.DriverManager;

public class IFAC_License_Type_Code {
	private static IFAC_License_Type_Code LicenseTypeinstance;

	private IFAC_License_Type_Code() {
		
	}

	public static IFAC_License_Type_Code getLicenseTypeinstance() {
		if (LicenseTypeinstance == null) {
			LicenseTypeinstance = new IFAC_License_Type_Code();
		}
		return LicenseTypeinstance;

}
	
	By License_Type_Code = By.xpath("//span[text()='License Type Code']");
	By License_Type = By.xpath("//label[text()='License Type']//following::input");
	By License_Type_Asset_Dropdown = By.xpath("//li[text()='Asset']");
	By License_Type_Employee_Dropdown = By.xpath("//li[text()='Employee']");
	By license_type_code = By.xpath("//label[text()='License Type Code']//following::input[1]");
	By License_Type_Description = By.xpath("//label[text()='License Type Description']//following::input[1]");
	By Search_License_Type_Desc = By.xpath("//input[@aria-label='License Type Description Filter Input']");
	By Search_License_Type_Code = By.xpath("//input[@aria-label='License Type Code Filter Input']");
	
	
	public void selectLicenseTypeCode() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(License_Type_Code);
		DriverManager.getDriver().findElement(License_Type_Code).click();
	}
	
	public void selectLicenseTypeAsset() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(License_Type);
		DriverManager.getDriver().findElement(License_Type).click();
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(License_Type_Asset_Dropdown);
		DriverManager.getDriver().findElement(License_Type_Asset_Dropdown).click();
	}
	
	public void enterLicenseTypeCode(String LT_Code) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(license_type_code);
		DriverManager.getDriver().findElement(license_type_code).sendKeys(LT_Code);
		
	}
	
	public void enterLicenseTypeDescription(String LT_Desc) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(License_Type_Description);
		DriverManager.getDriver().findElement(License_Type_Description).sendKeys(LT_Desc);
		
	}
	public void selectLicenseTypeEmployee() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(License_Type);
		DriverManager.getDriver().findElement(License_Type).click();
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(License_Type_Employee_Dropdown);
		DriverManager.getDriver().findElement(License_Type_Employee_Dropdown).click();
	}
	public void enternewLicenseTypeCode(String NLT_Code) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(license_type_code);
		DriverManager.getDriver().findElement(license_type_code).sendKeys(NLT_Code);
		
	}
	
	public void enternewLicenseTypeDescription(String NLT_Desc) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(License_Type_Description);
		DriverManager.getDriver().findElement(License_Type_Description).sendKeys(NLT_Desc);
		
	}
	public void SearchLicenseTypeDescription(String LT_Desc_Search) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Search_License_Type_Desc);
		DriverManager.getDriver().findElement(Search_License_Type_Desc).sendKeys(LT_Desc_Search);
		
	}
	
	
	public void editLicenseTypeDescription(String ELT_Desc) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(License_Type_Description);
		DriverManager.getDriver().findElement(License_Type_Description).clear();
		DriverManager.getDriver().findElement(License_Type_Description).sendKeys(ELT_Desc);
		
	}
	
	public void SearchLicenseTypeCode(String LT_Code_Search) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Search_License_Type_Code);
		DriverManager.getDriver().findElement(Search_License_Type_Code).sendKeys(LT_Code_Search);
		
	}
	
	public void enterInvalidLicenseTypeCode(String ILT_Code) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(license_type_code);
		DriverManager.getDriver().findElement(license_type_code).sendKeys(ILT_Code);
		
	}
	
	public void enterInvalidLicenseTypeDescription(String ILT_Description) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(License_Type_Description);
		DriverManager.getDriver().findElement(License_Type_Description).sendKeys(ILT_Description);
		
	}
	
	
	
	
	
	
	
	
	
}