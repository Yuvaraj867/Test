package com.lao.pageobjects;

import org.openqa.selenium.By;

import Utiliss.CommonUtilis;
import WEBDRIVER_Manager.DriverManager;

public class IFAC_Asset_Type_Code {
	private static IFAC_Asset_Type_Code AssetTypeCodeinstance;

	private IFAC_Asset_Type_Code() {

	}

	public static IFAC_Asset_Type_Code getAssetTypeCodeinstance() {
		if (AssetTypeCodeinstance == null) {
			AssetTypeCodeinstance = new IFAC_Asset_Type_Code();
		}
		return AssetTypeCodeinstance;
	}

	By AssetTypeCode = By.xpath("//span[text()='Asset Type Code']");
	By AssetClassification = By.id("classification-label");
	By AssetClassificationDropdown = By.xpath("//li[text()='Asset']");
	By AssetCategory = By.id("asset-category-search");
	By AssetCategoryDropdown = By.xpath("//li[text()='1020']");
	By NewAssetCategoryDropdown = By.xpath("//li[text()='1142']");
	By TypeCode = By.id("type-code");
	By TypeCodeDescription = By.id("type-code-description");
	By TypeCodeFilter = By.xpath("//input[@aria-label='Type Code Filter Input']");

	public void selectAssetTypeCode() {

		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(AssetTypeCode);
		DriverManager.getDriver().findElement(AssetTypeCode).click();

	}

	public void selectAssetClassification() {

		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(AssetClassification);
		DriverManager.getDriver().findElement(AssetClassification).click();
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(AssetClassificationDropdown);
		DriverManager.getDriver().findElement(AssetClassificationDropdown).click();

	}

	public void selectAssetCategory(String AC_Category) {

		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(AssetCategory);
		String formAssetCategory = AC_Category.contains(".") ? AC_Category.split("\\.")[0] : AC_Category;
		DriverManager.getDriver().findElement(AssetCategory).sendKeys(formAssetCategory);
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(AssetCategoryDropdown);
		DriverManager.getDriver().findElement(AssetCategoryDropdown).click();

	}
	
	public void selectNewAssetCategory(String New_AC_Category) {

		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(AssetCategory);
		String formNAssetCategory = New_AC_Category.contains(".") ? New_AC_Category.split("\\.")[0] : New_AC_Category;
		DriverManager.getDriver().findElement(AssetCategory).sendKeys(formNAssetCategory);
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(NewAssetCategoryDropdown);
		DriverManager.getDriver().findElement(NewAssetCategoryDropdown).click();

	}
	public void enterTypeCode(String TY_Code) {

		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(TypeCode);
		DriverManager.getDriver().findElement(TypeCode).sendKeys(TY_Code);

	}
	
	public void enterTypeCodeDescription(String TY_Code_Description) {

		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(TypeCodeDescription);
		DriverManager.getDriver().findElement(TypeCodeDescription).sendKeys(TY_Code_Description);

	}
	
	public void enterNewTypeCode(String New_TY_Code) {

		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(TypeCode);
		DriverManager.getDriver().findElement(TypeCode).sendKeys(New_TY_Code);

	}
	
	public void enterNewTypeCodeDescription(String New_TY_Code_Description) {

		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(TypeCodeDescription);
		DriverManager.getDriver().findElement(TypeCodeDescription).sendKeys(New_TY_Code_Description);

	}
	public void enterTypeCodeFilter(String Ty_Code_Search) {
		String formTY = Ty_Code_Search.contains(".") ? Ty_Code_Search.split("\\.")[0] : Ty_Code_Search;
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(TypeCodeFilter);
		DriverManager.getDriver().findElement(TypeCodeFilter).sendKeys(formTY);
	}
	
	public void editTypeCode(String E_TY_Code) {

		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(TypeCode);
		DriverManager.getDriver().findElement(TypeCode).sendKeys(E_TY_Code);

	}
	
	public void editTypeCodeDescription(String E_TY_Code_Description) {

		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(TypeCodeDescription);
		DriverManager.getDriver().findElement(TypeCodeDescription).sendKeys(E_TY_Code_Description);

	}
	
	public void enterInvalidTypeCode(String I_TY_Code) {

		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(TypeCode);
		DriverManager.getDriver().findElement(TypeCode).sendKeys(I_TY_Code);

	}
	
	public void enterInvalidTypeCodeDescription(String I_TY_Code_Description) {

		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(TypeCodeDescription);
		DriverManager.getDriver().findElement(TypeCodeDescription).sendKeys(I_TY_Code_Description);

	}
	
	
	
	
	

}
