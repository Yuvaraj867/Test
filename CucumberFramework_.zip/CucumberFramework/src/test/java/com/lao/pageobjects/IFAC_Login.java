package com.lao.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

import Constants.Constatine;
import Utiliss.CommonUtilis;
import WEBDRIVER_Manager.DriverManager;

public class IFAC_Login {
private static IFAC_Login Logininstance;
	
	private IFAC_Login() {
		
	}
	public static IFAC_Login getInstance() {
		if(Logininstance==null) {
			Logininstance = new IFAC_Login();
		}
		return Logininstance;
	}
	String URL;
	By Username = By.id("username");
	By Password = By.id("outlined-adornment-password");
	By InvalidUsername = By.id("username");
	By InvalidPassword = By.id("outlined-adornment-password");
	By Checkbox = By.xpath("//p[text()='Keep me logged In']//preceding::span[1]");
	By Submit = By.xpath("//button[@type='submit']");
	
	public void navigateToUrl(String url) {
		DriverManager.getDriver().navigate().to(url);
        
        }
	
	public void Username(String VUsername) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Username);
		DriverManager.getDriver().findElement(Username).clear();
		DriverManager.getDriver().findElement(Username).sendKeys(VUsername);
		
	}
	
	public void Password(String Vpassword) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Password);
		DriverManager.getDriver().findElement(Password).clear();
		DriverManager.getDriver().findElement(Password).sendKeys(Vpassword);
		
	}
	
	public void KeepMecheckbox() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Checkbox);
		DriverManager.getDriver().findElement(Checkbox).click();
	}
	
	public void Login() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Submit);
		DriverManager.getDriver().findElement(Submit).click();
		
	}
	
	public void InvalidUsername(String Iusername) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Username);
		DriverManager.getDriver().findElement(Username).sendKeys(Iusername);
		
	}
	
	public void InvalidPassword(String Ipassword) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Password);
		DriverManager.getDriver().findElement(Password).sendKeys(Ipassword);
		
	}
	
	public void Submit() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Submit);
		DriverManager.getDriver().findElement(Submit).click();
		
	}
	// I want to add or copy method from another class or same class 
	
	

	

}


