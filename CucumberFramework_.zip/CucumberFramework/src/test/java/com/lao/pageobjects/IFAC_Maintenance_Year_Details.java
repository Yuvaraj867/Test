package com.lao.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import Utiliss.CommonUtilis;
import WEBDRIVER_Manager.DriverManager;

public class IFAC_Maintenance_Year_Details {
private static IFAC_Maintenance_Year_Details Maintenanceinstance;
	
	private IFAC_Maintenance_Year_Details() {
		
	}
	public static IFAC_Maintenance_Year_Details getInstance() {
		if(Maintenanceinstance==null) {
			Maintenanceinstance = new IFAC_Maintenance_Year_Details();
		}
		return Maintenanceinstance;
		}
	
	By Maintenance_Year_Detail = By.xpath("//span[text()='Maintenance Year Details']");
	By Year_Filter = By.xpath("//input[@aria-label='Year Filter Input']");
	By Page_Size = By.xpath("//div[@aria-label='Page Size']");
	By Page_Size_Dropdown=By.xpath("//span[text()='20']");
	By Pagenation = By.xpath("//div[@aria-label='Last Page']");
	By Dashboard=By.xpath("//button[@aria-label='home']");

	public void selectMaintenanceYearDetail() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Maintenance_Year_Detail);
		DriverManager.getDriver().findElement(Maintenance_Year_Detail).click();
	}
	
	public void EnterYear(String Year) {
		 String formattedYear = Year.contains(".") ? Year.split("\\.")[0] : Year;
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Year_Filter);
		DriverManager.getDriver().findElement(Year_Filter).sendKeys(formattedYear);
		
	}
	
	public void EnterInvalidYear(String IYear) {
		 String formattedIYear = IYear.contains(".") ? IYear.split("\\.")[0] : IYear;
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Year_Filter);
		DriverManager.getDriver().findElement(Year_Filter).sendKeys(formattedIYear);
		
	}
	
	public void ClickPageSize() {
		
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Page_Size);
		DriverManager.getDriver().findElement(Page_Size).click();
	}
	

	public void ClickPageSizeDropdown() {
		
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Page_Size_Dropdown);
		DriverManager.getDriver().findElement(Page_Size_Dropdown).click();
	}
	
	
	public void ClickPagenation() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Pagenation);
		DriverManager.getDriver().findElement(Pagenation).click();
	}
	
	public void ClickHome() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Dashboard);
		DriverManager.getDriver().findElement(Dashboard).click();
	}
	
	
	
	
	
	
	
		
	
	
	
	

}
