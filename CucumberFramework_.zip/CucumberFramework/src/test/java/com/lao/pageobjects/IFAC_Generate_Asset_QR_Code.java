package com.lao.pageobjects;

import org.openqa.selenium.By;

public class IFAC_Generate_Asset_QR_Code {
	private static IFAC_Generate_Asset_QR_Code AssetQRCodeinstance;

	public static IFAC_Generate_Asset_QR_Code getUserdepinstance() {
		if (AssetQRCodeinstance == null) {
			AssetQRCodeinstance = new IFAC_Generate_Asset_QR_Code();
		}
		return AssetQRCodeinstance;
	}
	
	By Asset = By.xpath("//span[text()='Assets']//preceding::img[1]");
	By Generate_Asset_QR_Code = By.xpath("//span[text()='Generate Asset QR Code']");
	By Group_by = By.id("groupby");
	By Group_By_New_Asset = By.xpath("//li[text()='New Asset ']");
	By Group_By_Asset_Type_Code = By.xpath("//li[text()='Asset Type Code']");
	By New_Asset_No = By.xpath("//label[text()='New Asset  No.']//following::input[1]");
	By New_Asset_No_Lookup = By.xpath("//li[text()='H65BE00157 - Medical Refrigerator']");
	By Asset_Type_Code = By.xpath("//label[text()='Asset Type Code']//following::input[1]");
	By Asset_Type_Code_Lookup = By.xpath("//li[text()='040401 - External Civil Works, Sewerage, Sludge tank']");
	By Reset = By.xpath("//button[text()=' Reset']");
	By Find_Add = By.xpath("//button[text()='Find & Add']");
	By Generate_QR_Code = By.xpath("//button[text()='Generate QR Code']");
	By All_Checkbox = By.xpath("//input[@aria-label='Press Space to toggle all rows selection (unchecked)'][1]");
	By Print = By.xpath("//button[text()=' Print']");
	By Download_As_Pdf = By.xpath("//button[text()=' Download as PDF ']");
	By Download_As_Image = By.xpath("//button[text()='Download as Image ']");
	By Close = By.xpath("//button[text()='Close']");
	
	
	
	

}
