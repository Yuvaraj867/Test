package com.lao.pageobjects;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Utiliss.CommonUtilis;
import WEBDRIVER_Manager.DriverManager;

public class IFAC_Standard_Task {
	
	private static IFAC_Standard_Task Taskcodeinstance;
	
	private IFAC_Standard_Task() {
		
	}

	public static IFAC_Standard_Task getTaskcodeinstance() {
		if (Taskcodeinstance==null) {
			Taskcodeinstance = new IFAC_Standard_Task();
		}
		return Taskcodeinstance;
	}
	WebDriverWait wait;
	
	
	By Standard_Task_Detail = By.xpath("//span[text()='Standard Task Details']");
	By Service_FEMS = By.xpath("//li[text()='FEMS']");
	By Service_BEMS = By.xpath("//li[text()='BEMS']");
	By Service = By.xpath("//button[@title='Open']");
	By Work_Group = By.xpath("//input[@id='workgroup']//following::button");
	By Work_Group_Dropdown = By.xpath("//li[@id='workgroup-option-0']");
	By Task_Code = By.id("taskcode");
	By Task_Description= By.id("task-description");
	By Status = By.xpath("//label[text()='Status']//following::button");
	By StatusDropdownActive = By.xpath("//li[text()='Active']");
	By StatusDropdownInactive = By.xpath("//li[text()='Inactive']");
	By Datepicker = By.xpath("//input[@placeholder='DD/MM/YYYY']//following::button");
	By Date = By.xpath("//button[@type='button'][text()='1']");
	By Work_Instruction = By.id("modal-task-instructions");
	By WG_Search = By.xpath("//input[@aria-label='Work Group Filter Input']");
	
	public void selectStandardTaskDetail() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Standard_Task_Detail);
		DriverManager.getDriver().findElement(Standard_Task_Detail).click();
	}
	
	
	// Method to select an option from the dropdown
    public void selectServiceDropdown() {
    	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Service);
		DriverManager.getDriver().findElement(Service).click();
 }
    public void selectServiceFEMS() {
    	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Service_FEMS);
		DriverManager.getDriver().findElement(Service_FEMS).click();
 }
    public void selectServiceBEMS() {
    	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Service_BEMS);
		DriverManager.getDriver().findElement(Service_BEMS).click();
 }
	
	public void clickWorkGroup() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Work_Group);
		DriverManager.getDriver().findElement(Work_Group).click();
	}
	
	public void selectWorkGroupDropdown() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Work_Group_Dropdown);
		DriverManager.getDriver().findElement(Work_Group_Dropdown).click();
	}
	
	public void enterTaskCode(String TC) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Task_Code);
		DriverManager.getDriver().findElement(Task_Code).sendKeys(TC);
	}
	
	public void enterTaskDescription(String TC_Desc) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Task_Description);
		DriverManager.getDriver().findElement(Task_Description).sendKeys(TC_Desc);
	}
	
	public void editTaskDescription(String E_TC_Desc) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Task_Description);
		DriverManager.getDriver().findElement(Task_Description).sendKeys(E_TC_Desc);
	}
	
	public void selectStatusActive() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Status);
		DriverManager.getDriver().findElement(Status).click();
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(StatusDropdownActive);
		DriverManager.getDriver().findElement(StatusDropdownActive).click();
		
	}
	
	public void selectStatusInActive() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Status);
		DriverManager.getDriver().findElement(Status).click();
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(StatusDropdownInactive);
		DriverManager.getDriver().findElement(StatusDropdownInactive).click();
		
	}
	
	public void clickDatepicker() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Datepicker);
		DriverManager.getDriver().findElement(Datepicker).click();
		
	}
	
	public void selectDate() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Date);
		DriverManager.getDriver().findElement(Date).click();
		
	}
	
	public void enterWorkInstruction(String Work_Ins) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Work_Instruction);
		DriverManager.getDriver().findElement(Work_Instruction).sendKeys(Work_Ins);
		
	}
	
	
	
	public void enterNewTaskCode(String New_TC) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Task_Code);
		DriverManager.getDriver().findElement(Task_Code).sendKeys(New_TC);
		
	}
	public void enterNewTaskDescription(String New_TC_Desc) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Task_Description);
		DriverManager.getDriver().findElement(Task_Description).sendKeys(New_TC_Desc);
		
	}
	
	public void enterInvalidTaskCode(String ITC) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Task_Code);
		DriverManager.getDriver().findElement(Task_Code).sendKeys(ITC);
		
	}
	
	public void enterInvalidTaskDescription(String ITC_Desc) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Task_Description);
		DriverManager.getDriver().findElement(Task_Description).sendKeys(ITC_Desc);
		
	}
	
	
	
	
	public void enterWGSearchFilter(String ST_Details_Search) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(WG_Search);
		DriverManager.getDriver().findElement(WG_Search).sendKeys(ST_Details_Search);
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
