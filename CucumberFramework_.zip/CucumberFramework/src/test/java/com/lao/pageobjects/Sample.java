package com.lao.pageobjects;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import Utiliss.CommonUtilis;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;

public class Sample {

    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        
       driver.get("http://ifacxdemo.changepond.com/");
        driver.manage().window().maximize();
      
        // Login
        
   WebElement enterUserName =     driver.findElement(By.id("username"));
   
   enterUserName.sendKeys("Superadmin");
        driver.findElement(By.id("outlined-adornment-password")).sendKeys("Welcome@123");
        Thread.sleep(3000);
        driver.findElement(By.xpath("//p[text()='Keep me logged In']//preceding::span[1]")).click();
        Thread.sleep(3000);
        driver.findElement(By.xpath("//button[@type='submit']")).click();
        Thread.sleep(3000);
        
        
        WebElement dropdown=  driver.findElement(By.xpath("//label[text()='Module']//following::div"));
        dropdown.click();
       driver.findElement(By.xpath("//li[text()='Engineering Management System']")).click();
       
       WebElement dropdown1=  driver.findElement(By.xpath("//label[text()='Company']//following::div"));
       dropdown1.click();
      driver.findElement(By.xpath("//li[text()='Pantai Medical Center']")).click();
        
        
        
        
        
        
      WebElement dropdown2=  driver.findElement(By.xpath("//label[text()='Location']//following::div"));
      dropdown2.click();
     driver.findElement(By.xpath("//li[text()='Pantai Hospital Klang']")).click();
        

        // Click the button
        driver.findElement(By.xpath("//button[@type='button'][1]")).click();
        Thread.sleep(3000);

        // Navigate to HospitalMaster
        WebElement hospitalMasterIcon = driver.findElement(By.xpath("//img[@alt='HospitalMaster']"));
        Actions actions = new Actions(driver);
        actions.moveToElement(hospitalMasterIcon).click().perform();
        Thread.sleep(3000);

        // Navigate to Work Group
        driver.findElement(By.xpath("//span[text()='Work Group']")).click();

        // Create New Work Group
        driver.findElement(By.xpath("//button[text()='Create New']")).click();
        Thread.sleep(3000);

        // Open selection and select an option
        WebElement openButton = driver.findElement(By.xpath("//button[@title='Open']"));
        openButton.click();
        Thread.sleep(3000);

        // Select an option from the dropdown
        driver.findElement(By.xpath("//li[@id='service-label-option-0']")).click();

        // Enter work group details
        driver.findElement(By.id("work-group-code")).sendKeys("W93");
        driver.findElement(By.id("work-group-description")).sendKeys("test33");

        // Save the work group
        WebElement saveButton = driver.findElement(By.xpath("//button[text()='Save']"));
        saveButton.click();

      Thread.sleep(3000);
      
      driver.findElement(By.xpath("//p[text()='Data saved successfully.']//following::button")).click();
      Thread.sleep(3000);
      driver.findElement(By.xpath("//button[text()='Add New']")).click();
      Thread.sleep(3000);
      driver.findElement(By.xpath("//p[text()='Record(s) not Saved/Updated. Do you want to continue?']//following::button[1]")).click();
      Thread.sleep(3000);
      
      openButton.click();
      Thread.sleep(3000);
      driver.findElement(By.xpath("//li[@id='service-label-option-0']")).click();
      Thread.sleep(3000);
      // Enter work group details
      driver.findElement(By.id("work-group-code")).sendKeys("W94");
      driver.findElement(By.id("work-group-description")).sendKeys("test2333");
      saveButton.click();
      Thread.sleep(3000);
      driver.findElement(By.xpath("//p[text()='Data saved successfully.']//following::button")).click();
      Thread.sleep(3000);
      driver.findElement(By.xpath("//button[text()='Back']")).click();
      Thread.sleep(3000);
      driver.findElement(By.xpath("//p[text()='Record(s) not Saved/Updated. Do you want to continue?']//following::button[1]")).click();
      Thread.sleep(3000);
      driver.findElement(By.xpath("//input[@aria-label='Work Group Code Filter Input']")).sendKeys("W93");
      Thread.sleep(3000);
      driver.findElement(By.xpath("//button[@aria-label='Edit']")).click();
      Thread.sleep(3000);
      driver.findElement(By.id("work-group-description")).sendKeys("test233357");
      Thread.sleep(3000);
      driver.findElement(By.xpath("//button[text()='Update']")).click();
      Thread.sleep(3000);
      driver.findElement(By.xpath("//p[text()='Data updated successfully.']//following::button")).click();
      Thread.sleep(3000);
      driver.findElement(By.id("work-group-description")).sendKeys("test23335789");
      Thread.sleep(3000);
      driver.findElement(By.xpath("//button[text()='Back']")).click();
      Thread.sleep(3000);
      driver.findElement(By.xpath("//p[text()='Record(s) not Saved/Updated. Do you want to continue?'']//following::button[1]")).click();
      Thread.sleep(3000);
      driver.findElement(By.xpath("//input[@aria-label='Work Group Code Filter Input']")).sendKeys("w233");
      Thread.sleep(3000);
      
      driver.findElement(By.xpath("//button[@aria-label='View']")).click();
      Thread.sleep(3000);
      driver.findElement(By.xpath("//button[text()='Back']")).click();
      Thread.sleep(3000);
      driver.findElement(By.xpath("//input[@aria-label='Work Group Code Filter Input']")).sendKeys("W93");
      Thread.sleep(3000);
      driver.findElement(By.xpath("//button[@aria-label='Delete']")).click();
      Thread.sleep(3000);
      driver.findElement(By.xpath("//p[text()='Are you sure you want to delete?']//following::button[1]")).click();
      Thread.sleep(3000);
      driver.findElement(By.xpath("//p[text()='Record deleted successfully.']//following::button")).click();
      
      

        // Click OK and Cancel
       // driver.findElement(By.xpath("//button[text()='ok']")).click();
       // driver.findElement(By.xpath("//button[text()='Cancel']")).click();

        // Close the browser
       // driver.quit();
    }
}