package com.lao.pageobjects;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Utiliss.CommonUtilis;
import WEBDRIVER_Manager.DriverManager;

public class IFAC_Department_Work_Request {
	private static IFAC_Department_Work_Request WorkRequestinstance;

	private IFAC_Department_Work_Request() {

	}

	public static IFAC_Department_Work_Request getWorkRequestinstance() {
		if (WorkRequestinstance == null) {
			WorkRequestinstance = new IFAC_Department_Work_Request();
		}
		return WorkRequestinstance;
	}

	By Maintenance = By.xpath("//span[text()='Maintenance']//preceding::img[1]");
	By Department_Work_Request = By.xpath("//span[text()='Department Work Request']");
	By DWRequestor = By.id("requestor");
	By DWDesignation = By.id("designation");
	By DWContactNo = By.id("contactno");
	By DWAssetNO = By.id("assetno-search");
	By DWAssetNolookup =By.xpath("//li[text()='H15BE00001 - Electrical Safety Analyzer']");
	By NewAssetNolookup =By.xpath("//li[text()='H15BE00003 - Anaesthetic Machine (Datex-Ohmeda)']");
	By DWCategory = By.id("Category");
	By Category_Dropdown = By.xpath("//li[text()='Others']");
	By DWType = By.id("Type");
	By Type_Dropdown = By.xpath("//li[text()='Safety & Performance']");
	By DWRequest_Details = By.id("requestdetails");
	By DWSearch_Work_Request_No = By.xpath("//input[@aria-label='Work Request No. Filter Input']");
    By Work_Request_Description = By.xpath("//input[@aria-label='Work Request Description Filter Input']");
	public void selectMaintenance() {

		// Wait for the element to be visible
	    CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Maintenance);
	    
	    try {
	        // Try to click the element directly
	        WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(), Duration.ofSeconds(10));
	        wait.until(ExpectedConditions.elementToBeClickable(Maintenance));
	        DriverManager.getDriver().findElement(Maintenance).click();
	        
	    } catch (ElementClickInterceptedException e) {
	        // If the click is intercepted, click once using JavaScript (no additional attempt to click normally)
	        WebElement element = DriverManager.getDriver().findElement(Maintenance);
	        JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
	        js.executeScript("arguments[0].click();", element);
	    }
	}
	
		
	
	public void enterWorkRequestDesc(String Work_Desc_Search ) {
		

		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Work_Request_Description);
		DriverManager.getDriver().findElement(Work_Request_Description).sendKeys(Work_Desc_Search);
		}
	public void selectDepartmentWorkRequest() {

		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Department_Work_Request);
		DriverManager.getDriver().findElement(Department_Work_Request).click();
		}
	
	public void enterRequestor(String Requestor) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DWRequestor);
		DriverManager.getDriver().findElement(DWRequestor).sendKeys(Requestor);
		}
	
	public void enterDesignation(String Designation) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DWDesignation);
		DriverManager.getDriver().findElement(DWDesignation).sendKeys(Designation);
		}
	
	public void enterContactNo(String Contact_No) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DWContactNo);
		DriverManager.getDriver().findElement(DWContactNo).sendKeys(Contact_No);
		}
	public void selectAssetNo(String AssetNo) {

		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DWAssetNO);
		DriverManager.getDriver().findElement(DWAssetNO).sendKeys(AssetNo);
	    CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DWAssetNolookup);
		DriverManager.getDriver().findElement(DWAssetNolookup).click();

	}
	public void selectCategory() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DWCategory);
		DriverManager.getDriver().findElement(DWCategory).click();
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Category_Dropdown);
		DriverManager.getDriver().findElement(Category_Dropdown).click();
		}
	public void selectType() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DWType);
		DriverManager.getDriver().findElement(DWType).click();
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Type_Dropdown);
		DriverManager.getDriver().findElement(Type_Dropdown).click();
	}
	public void enterRequestDetails(String Req_Details) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DWRequest_Details);
		DriverManager.getDriver().findElement(DWRequest_Details).sendKeys(Req_Details);
		}
	public void enternewRequestor(String NRequestor) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DWRequestor);
		DriverManager.getDriver().findElement(DWRequestor).sendKeys(NRequestor);
		}
	
	public void enternewDesignation(String NDesignation) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DWDesignation);
		DriverManager.getDriver().findElement(DWDesignation).sendKeys(NDesignation);
		}
	
	public void enternewContactNo(String NContact_No) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DWContactNo);
		DriverManager.getDriver().findElement(DWContactNo).sendKeys(NContact_No);
		}
	
	public void selectnewAssetNo(String NAssetNo) {

		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DWAssetNO);
		DriverManager.getDriver().findElement(DWAssetNO).sendKeys(NAssetNo);
	    CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(NewAssetNolookup);
		DriverManager.getDriver().findElement(NewAssetNolookup).click();

	}
	
	
	public void enterWorkRequestNo(String Work_Request_Search) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DWSearch_Work_Request_No);
		DriverManager.getDriver().findElement(DWSearch_Work_Request_No).sendKeys(Work_Request_Search);
		}
	public void editRequestor(String ERequestor) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DWRequestor);
		DriverManager.getDriver().findElement(DWRequestor).sendKeys(ERequestor);
		}
	
	public void editDesignation(String EDesignation) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DWDesignation);
		DriverManager.getDriver().findElement(DWDesignation).sendKeys(EDesignation);
		}
	
	public void editContactNo(String EContact_No) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DWContactNo);
		DriverManager.getDriver().findElement(DWContactNo).sendKeys(EContact_No);
		}
	
	public void editRequestDetails(String EReq_Details) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DWRequest_Details);
		DriverManager.getDriver().findElement(DWRequest_Details).sendKeys(EReq_Details);
		}
	public void enterInvalidRequestor(String IRequestor) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DWRequestor);
		DriverManager.getDriver().findElement(DWRequestor).sendKeys(IRequestor);
		}
	
	public void enterInvalidDesignation(String IDesignation) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DWDesignation);
		DriverManager.getDriver().findElement(DWDesignation).sendKeys(IDesignation);
		}
	
	public void enterInvalidContactNo(String IContact_No) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DWContactNo);
		DriverManager.getDriver().findElement(DWContactNo).sendKeys(IContact_No);
		}
	
	public void enterInvalidRequestDetails(String IReq_Details) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DWRequest_Details);
		DriverManager.getDriver().findElement(DWRequest_Details).sendKeys(IReq_Details);
		}
	
	
	
}
