package com.lao.pageobjects;

import org.openqa.selenium.By;

import Utiliss.CommonUtilis;
import WEBDRIVER_Manager.DriverManager;

public class IFAC_Asset_Category {
	private static IFAC_Asset_Category AssetCategoryinstance;

	private IFAC_Asset_Category() {

	}

	public static IFAC_Asset_Category getAssetCategoryinstance() {
		if (AssetCategoryinstance == null) {
			AssetCategoryinstance = new IFAC_Asset_Category();
		}
		return AssetCategoryinstance;
	}
    By Asset_Category = By.xpath("//span[text()='Asset Category']");
	By Asset_Category_Code = By.id("asset-category");
	By Asset_Category_Description = By.id("asset-category-description");
	By Asset_Category_Filter = By.xpath("//input[@aria-label='Asset Category Code Filter Input']");
	By Asset_Category_Duplicate = By.xpath("//p[text()='Asset Catgeory Already Exists']//following::button");
	
	public void selectAssetCategory() {

		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Asset_Category);
		DriverManager.getDriver().findElement(Asset_Category).click();

	}

	public void enterAssetCategoryCode(String AC_Code) {

		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Asset_Category_Code);
		DriverManager.getDriver().findElement(Asset_Category_Code).sendKeys(AC_Code);

	}

	public void enterAssetCategoryDescription(String AC_Des) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Asset_Category_Description);
		DriverManager.getDriver().findElement(Asset_Category_Description).sendKeys(AC_Des);
	}

	public void enterNewAssetCategoryCode(String New_AC_Code) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Asset_Category_Code);
		DriverManager.getDriver().findElement(Asset_Category_Code).sendKeys(New_AC_Code);
	}

	public void enterNewAssetCategoryDescription(String New_AC_Des) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Asset_Category_Description);
		DriverManager.getDriver().findElement(Asset_Category_Description).sendKeys(New_AC_Des);
	}
	
	public void editAssetCategoryDescription(String AC_Des_E) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Asset_Category_Description);
		DriverManager.getDriver().findElement(Asset_Category_Description).sendKeys(AC_Des_E);
	}
	
	public void enterAssetCategoryFilter(String AC_Code_Search) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Asset_Category_Filter);
		DriverManager.getDriver().findElement(Asset_Category_Filter).sendKeys(AC_Code_Search);
	}
	
	public void enterInvalidAssetCategoryCode(String IAC_Code) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Asset_Category_Code);
		DriverManager.getDriver().findElement(Asset_Category_Code).sendKeys(IAC_Code);
	}
	
	public void enterInvalidAssetCategoryDescription(String IAC_Description) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Asset_Category_Description);
		DriverManager.getDriver().findElement(Asset_Category_Description).sendKeys(IAC_Description);
	}
	
	public void selectAssetCategoryDuplicate() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Asset_Category_Duplicate);
		DriverManager.getDriver().findElement(Asset_Category_Duplicate).click();
	}
	
	


	
}