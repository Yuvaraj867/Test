package com.lao.pageobjects;

import org.openqa.selenium.By;

import Utiliss.CommonUtilis;
import WEBDRIVER_Manager.DriverManager;

public class IFAC_User_Location {
private static IFAC_User_Location UserLocationinstance;

private IFAC_User_Location() {
	
}

public static IFAC_User_Location getUserLocationinstance() {
	if (UserLocationinstance == null) {
		UserLocationinstance = new IFAC_User_Location();
	}
	return UserLocationinstance;
}

By User_Location = By.xpath("//span[text()='User Location']");
By Location_Code = By.id("user-location-code");
By Location_Name = By.id("location-name");
By Department_Description = By.id("department-description-search");
By Dep_Des_lookupA = By.xpath("//li[text()=' Administration - A02 ']");
By DEP_Des_LookupB = By.xpath("//li[text()=' Cardiology - C01 ']");
By Dep_Des_Clear = By.xpath("//input[@id='department-description-search']//following::button[2]");
By Status = By.xpath("//label[text()='Status']//following::button[2]");
By StatusDropdownActive = By.xpath("//li[text()='Active']");
By StatusDropdownInactive = By.xpath("//li[@id='status-option-1']");
By Location_Code_Search = By.xpath("//input[@aria-label='Location Code Filter Input']");

public void selectUserLocation() {
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(User_Location);
	DriverManager.getDriver().findElement(User_Location).click();
}

public void enterLocationCode(String LC_Code) {
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Location_Code);
	String formLCode = LC_Code.contains(".") ? LC_Code.split("\\.")[0] : LC_Code;
	DriverManager.getDriver().findElement(Location_Code).sendKeys(formLCode);
}

public void enterLocationName(String LC_Name) {
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Location_Name);
	DriverManager.getDriver().findElement(Location_Name).sendKeys(LC_Name);
}

public void selectDepartmentDescription(String DE_DESC) {
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Department_Description);
	DriverManager.getDriver().findElement(Department_Description).sendKeys(DE_DESC);
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Dep_Des_lookupA);
	DriverManager.getDriver().findElement(Dep_Des_lookupA).click();
	
}

public void enterNewLocationCode(String NLC_Code) {
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Location_Code);
	String formNLCode = NLC_Code.contains(".") ? NLC_Code.split("\\.")[0] : NLC_Code;
	DriverManager.getDriver().findElement(Location_Code).sendKeys(formNLCode);
}

public void enterNewLocationName(String NLC_Name) {
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Location_Name);
	DriverManager.getDriver().findElement(Location_Name).sendKeys(NLC_Name);
}

public void enterUserLocationCode(String UL_Code_Search) {
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Location_Code_Search);
	String formULCode = UL_Code_Search.contains(".") ? UL_Code_Search.split("\\.")[0] : UL_Code_Search;
	DriverManager.getDriver().findElement(Location_Code_Search).sendKeys(formULCode);
}
public void selectStatusActive() {
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Status);
	DriverManager.getDriver().findElement(Status).click();
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(StatusDropdownActive);
	DriverManager.getDriver().findElement(StatusDropdownActive).click();
}

public void selectStatusInActive() {
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Status);
	DriverManager.getDriver().findElement(Status).click();
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(StatusDropdownInactive);
	DriverManager.getDriver().findElement(StatusDropdownInactive).click();
}

public void editLocationName(String ELC_Name) {
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Location_Name);
	DriverManager.getDriver().findElement(Location_Name).sendKeys(ELC_Name);
}

public void editDepartmentDescription(String EDE_DESC) {
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Dep_Des_Clear);
	DriverManager.getDriver().findElement(Dep_Des_Clear).click();
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Department_Description);
	DriverManager.getDriver().findElement(Department_Description).sendKeys(EDE_DESC);
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DEP_Des_LookupB);
	DriverManager.getDriver().findElement(DEP_Des_LookupB).click();
	
}

public void enterInvalidLocationCode(String ILC_Code) {
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Location_Code);
	DriverManager.getDriver().findElement(Location_Code).sendKeys(ILC_Code);
}

public void enterInvalidLocationName(String ILC_Name) {
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Location_Name);
	DriverManager.getDriver().findElement(Location_Name).sendKeys(ILC_Name);
}









}
