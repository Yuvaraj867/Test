package com.lao.pageobjects;

import org.openqa.selenium.By;

import Utiliss.CommonUtilis;
import WEBDRIVER_Manager.DriverManager;

public class IFAC_User_Department {
	
private static IFAC_User_Department Userdepinstance;

public static IFAC_User_Department getUserdepinstance() {
	if (Userdepinstance == null) {
		Userdepinstance = new IFAC_User_Department();
	}
	return Userdepinstance;
}

By UserDepartment = By.xpath("//span[text()='User Department']");
By DepCode = By.id("department-code");
By DepDesc = By.id("department-description");
By Dep_Search_Filter = By.xpath("//input[@aria-label='Department Code Filter Input']");
By Dep_Code_Del_Alert_Msg = By.xpath("//p[text()='The Department Code is already in use']//following::button");

public void selectUserDepartment() {
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(UserDepartment);
	DriverManager.getDriver().findElement(UserDepartment).click();
}
	

public void enterDepCode(String Dep_Code ) {
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DepCode);
	DriverManager.getDriver().findElement(DepCode).sendKeys(Dep_Code);
}
public void enterDepDesc(String Dep_Desc) {
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DepDesc);
	DriverManager.getDriver().findElement(DepDesc).sendKeys(Dep_Desc);
	}

public void enterNewDepCode(String New_Dep_Code ) {
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DepCode);
	DriverManager.getDriver().findElement(DepCode).sendKeys(New_Dep_Code);
}

public void enterNewDepDesc(String New_Dep_Des) {
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DepDesc);
	DriverManager.getDriver().findElement(DepDesc).sendKeys(New_Dep_Des);
	}

public void enterDep_Search_Filter(String Dep_Code_Search) {
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Dep_Search_Filter);
	DriverManager.getDriver().findElement(Dep_Search_Filter).sendKeys(Dep_Code_Search);}

public void editDepDesc(String Dep_Desc_E) {
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DepDesc);
	DriverManager.getDriver().findElement(DepDesc).sendKeys(Dep_Desc_E);
	}
public void clickDepCodeDeleteAlertMsg() {
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Dep_Code_Del_Alert_Msg);
	DriverManager.getDriver().findElement(Dep_Code_Del_Alert_Msg).click();
}


public void enterInvalidDepCode(String IDep_Code ) {
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DepCode);
	DriverManager.getDriver().findElement(DepCode).sendKeys(IDep_Code);
}

public void enterInvalidDepDesc(String IDep_Description) {
	CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(DepDesc);
	DriverManager.getDriver().findElement(DepDesc).sendKeys(IDep_Description);
	}






}

