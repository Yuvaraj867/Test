package com.lao.pageobjects;

import org.openqa.selenium.By;

import Utiliss.CommonUtilis;
import WEBDRIVER_Manager.DriverManager;

public class IFAC_Welcome_Page {
private static IFAC_Welcome_Page Welcomeinstance;
	
	private IFAC_Welcome_Page() {
		
	}
	public static IFAC_Welcome_Page getInstance() {
		if(Welcomeinstance==null) {
			Welcomeinstance = new IFAC_Welcome_Page();
		}
		return Welcomeinstance;
		}
	    
	    By Back = By.xpath("//button[text()='Back']");
		
		By Module = By.xpath("//label[text()='Module']//following::div");
		By ModuleDropdown = By.xpath("//li[text()='Engineering Management System']");
		
		By Company = By.xpath("//label[text()='Company']//following::div");
		By CompanyDropdown=By.xpath("//li[text()='Pantai Medical Center']");
		
		By Location = By.xpath("//label[text()='Location']//following::div");
		By LocationDropdown = By.xpath("//li[text()='Pantai Hospital Klang']");
		
		By Continue = By.xpath("//button[text()='Continue']");
		
		public void selectModule() {
			CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Module);
			DriverManager.getDriver().findElement(Module).click();
			CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(ModuleDropdown);
			DriverManager.getDriver().findElement(ModuleDropdown).click();
			
		}
		
		public void selectCompany() {
			CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Company);
			DriverManager.getDriver().findElement(Company).click();
			CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(CompanyDropdown);
			DriverManager.getDriver().findElement(CompanyDropdown).click();
		}
		
		public void selectLocation() {
			CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Location);
			DriverManager.getDriver().findElement(Location).click();
			CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(LocationDropdown);
			DriverManager.getDriver().findElement(LocationDropdown).click();
		
		
	}
		
		public void clickBack() {
			CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Back);
			DriverManager.getDriver().findElement(Back).click();
		}
		
		public void clickContinue() {
			CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Continue);
			DriverManager.getDriver().findElement(Continue).click();
		}
	
	

}
