package com.lao.pageobjects;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Constants.Constatine;
import Utiliss.CommonUtilis;
import WEBDRIVER_Manager.DriverManager;

public class IFAC_Work_Group {

	private static IFAC_Work_Group Workgroupinstance;

	private IFAC_Work_Group() {

	}

	public static IFAC_Work_Group getWorkgroupinstance() {
		if (Workgroupinstance == null) {
			Workgroupinstance = new IFAC_Work_Group();
		}
		return Workgroupinstance;
	}

	By Hospital_Masters = By.xpath("//span[text()='Hospital Masters']//preceding::img[1]");
	By Work_Group = By.xpath("//span[text()='Work Group']");
	By Create_New = By.xpath("//button[text()='Create New']");
	By Service = By.xpath("//button[@title='Open']");
	By Service_Dropdown = By.xpath("//li[@id='service-label-option-0']");
	By Work_Group_Code = By.id("work-group-code");
	By Work_Group_Description = By.id("work-group-description");
	By Save_Button = By.xpath("//button[text()='Save']");
	By Save_Msg = By.xpath("//p[text()='Data saved successfully.']//following::button");
	By Add_New_Button = By.xpath("//button[text()='Add New']");
	By Back_Confirm_Msg = By.xpath("//p[text()='Record(s) not Saved/Updated. Do you want to continue?']//following::button[1]");
	By Back_Button = By.xpath("//button[text()='Back']");
	By Work_Group_Filter = By.xpath("//input[@aria-label='Work Group Code Filter Input']");
	By Edit_Icon = By.xpath("//button[@aria-label='Edit']");
	By Update_Button = By.xpath("//button[text()='Update']");
	By UpdateMsg = By.xpath("//p[text()='Data updated successfully.']//following::button");
	By View_Icon = By.xpath("//button[@aria-label='View']");
	By Refresh_Icon = By.xpath("//button[@aria-label='Refresh']");
	By Export_Icon = By.xpath("//button[@aria-label='Export']");
	By Excel = By.xpath("//li[text()='csv']");
	By Delete_Icon = By.xpath("//button[@aria-label='Delete']");
	By Delete_Confirm_Msg = By.xpath("//p[text()='Are you sure you want to delete?']//following::button[1]");
	By Delete_Success_Msg = By.xpath("//p[text()='Record deleted successfully.']//following::button");
	By Delete_Alert_Msg = By.xpath("//p[text()='Record cannot be deleted as it is referred in another record.']//following::button");
	By Work_Group_Duplicate_Msg = By.xpath("//p[text()='Work Group Already Exists']//following::button");
	By Pagenation = By.xpath("//div[@aria-label='Last Page']");
	By Work_Group_Desc_Filter = By.xpath("//input[@aria-label='Work Group Description Filter Input']");
	
	public void selectHospitalMasters() {
	
		// Wait for the element to be visible
	    CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Hospital_Masters);
	    
	    try {
	        // Try to click the element directly
	        WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(), Duration.ofSeconds(10));
	        wait.until(ExpectedConditions.elementToBeClickable(Hospital_Masters));
	        DriverManager.getDriver().findElement(Hospital_Masters).click();
	        
	    } catch (ElementClickInterceptedException e) {
	        // If the click is intercepted, click once using JavaScript (no additional attempt to click normally)
	        WebElement element = DriverManager.getDriver().findElement(Hospital_Masters);
	        JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
	        js.executeScript("arguments[0].click();", element);
	    }
	}
	

	public void selectWorkGroup() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Work_Group);
		DriverManager.getDriver().findElement(Work_Group).click();

	}

	public void clickCreateNew() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Create_New);
		DriverManager.getDriver().findElement(Create_New).click();

	}

	public void selectService() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Service);
		DriverManager.getDriver().findElement(Service).click();
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Service_Dropdown);
		DriverManager.getDriver().findElement(Service_Dropdown).click();

	}

	public void enterWorkGroupCode(String WG_Code) {

		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Work_Group_Code);
		DriverManager.getDriver().findElement(Work_Group_Code).sendKeys(WG_Code);

	}

	public void enterWorkGroupDescription(String WG_Des) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Work_Group_Description);
		DriverManager.getDriver().findElement(Work_Group_Description).sendKeys(WG_Des);
	}

	public void clickSaveButton() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Save_Button);
		DriverManager.getDriver().findElement(Save_Button).click();

	}

	public void clickSaveAlertMsg() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Save_Msg);
		DriverManager.getDriver().findElement(Save_Msg).click();
	}

	public void clickAddNewButton() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Add_New_Button);
		DriverManager.getDriver().findElement(Add_New_Button).click();
	}

	public void enterNewWorkGroupCode(String New_WG_Code) {
		String datetime = new SimpleDateFormat("ss").format(new Date());
		String NewWGName = New_WG_Code + datetime;
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Work_Group_Code);
		DriverManager.getDriver().findElement(Work_Group_Code).sendKeys(NewWGName);

	}

	public void enterNewWorkGroupDescription(String New_WG_Des) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Work_Group_Description);
		DriverManager.getDriver().findElement(Work_Group_Description).sendKeys(New_WG_Des);
	}

	public void clickBackConMsg() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Back_Confirm_Msg);
		DriverManager.getDriver().findElement(Back_Confirm_Msg).click();
	}

	public void clickBackButton() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Back_Button);
		DriverManager.getDriver().findElement(Back_Button).click();
	}

	public void enterWorkGroupFilter(String WG_Code_Search) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Work_Group_Filter);
		DriverManager.getDriver().findElement(Work_Group_Filter).sendKeys(WG_Code_Search);
	}
	

	public void enterWorkGroupDescFilter(String WG_Des_Search) {
		
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Work_Group_Desc_Filter);
		DriverManager.getDriver().findElement(Work_Group_Desc_Filter).sendKeys(WG_Des_Search);
	}

	public void clickEditIcon() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Edit_Icon);
		DriverManager.getDriver().findElement(Edit_Icon).click();
	}

	public void editWrokGroupDescription(String WG_Des_E) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Work_Group_Description);
		DriverManager.getDriver().findElement(Work_Group_Description).sendKeys(WG_Des_E);
	}

	public void selectUpdateButton() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Update_Button);
		DriverManager.getDriver().findElement(Update_Button).click();
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(UpdateMsg);
		DriverManager.getDriver().findElement(UpdateMsg).click();
	}

	public void enterInvalidWorkGroupCode(String IWG_Code) {

		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Work_Group_Code);
		DriverManager.getDriver().findElement(Work_Group_Code).sendKeys(IWG_Code);
	}

	public void enterInvalidWorkGroupDescription(String IWG_Des) {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Work_Group_Description);
		DriverManager.getDriver().findElement(Work_Group_Description).sendKeys(IWG_Des);
	}

	public void clickViewIcon() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(View_Icon);
		DriverManager.getDriver().findElement(View_Icon).click();
	}

	public void clickRefreshIcon() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Refresh_Icon);
		DriverManager.getDriver().findElement(Refresh_Icon).click();

	}

	public void clickExportIcon() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Export_Icon);
		DriverManager.getDriver().findElement(Export_Icon).click();
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Excel);
		DriverManager.getDriver().findElement(Excel).click();
	}

	public void clickDeleteIcon() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Delete_Icon);
		DriverManager.getDriver().findElement(Delete_Icon).click();

	}

	public void clickDeleteConfirmMsg() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Delete_Confirm_Msg);
		DriverManager.getDriver().findElement(Delete_Confirm_Msg).click();
		//CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Delete_Success_Msg);
		//DriverManager.getDriver().findElement(Delete_Success_Msg).click();
	}
	
	public void clickDeleteSuccessMsg() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Delete_Success_Msg);
		DriverManager.getDriver().findElement(Delete_Success_Msg).click();
	}

	public void clickDeleteAlertMsg() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Delete_Alert_Msg);
		DriverManager.getDriver().findElement(Delete_Alert_Msg).click();

	}
	
	public void clickWorkGroupDuplicate() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Work_Group_Duplicate_Msg);
		DriverManager.getDriver().findElement(Work_Group_Duplicate_Msg).click();
	}
	public void clickPagenation() {
		CommonUtilis.getCommonutilisinstance().WaitForElementVisibility(Pagenation);
		DriverManager.getDriver().findElement(Pagenation).click();
	}
	
	public void driverClose() {
		DriverManager.getDriver().close();
	}

}
