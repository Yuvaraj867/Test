package com.lao.Exceldata;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class TestDataInitializer {
    private ExcelReader excelReader;
    private Map<String, Map<String, String>> allTestData;

    public TestDataInitializer(String filePath, String sheetName) throws IOException {
        this.excelReader = new ExcelReader(filePath, sheetName);
        this.allTestData = excelReader.readExcelData();
    }

    public Map<String, String> getTestData(String testCase) {
        Map<String, String> testData = allTestData.get(testCase);

        if (testData != null) {
         //   System.out.println("Loaded data for " + testCase + ": " + testData);
            return testData;
        } else {
          //  System.out.println("No data found for test case: " + testCase);
            return new HashMap<>(); // Return empty map if no data is found
        }
    }
}