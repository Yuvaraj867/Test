package com.lao.Exceldata;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ExcelReader {
    private String filePath;
    private String sheetName;

    public ExcelReader(String filePath, String sheetName) {
        this.filePath = filePath;
        this.sheetName = sheetName;
    }

    public Map<String, Map<String, String>> readExcelData() throws IOException {
        Map<String, Map<String, String>> excelData = new HashMap<>();
        
        try (FileInputStream file = new FileInputStream(new File(filePath));
             XSSFWorkbook workbook = new XSSFWorkbook(file)) {

            Sheet sheet = workbook.getSheet(sheetName);
            Row headerRow = sheet.getRow(0);
            int columnCount = headerRow.getLastCellNum();

            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row currentRow = sheet.getRow(i);
                Map<String, String> rowData = new HashMap<>();

                for (int j = 0; j < columnCount; j++) {
                    if (currentRow != null && currentRow.getCell(j) != null) {
                        String columnName = headerRow.getCell(j).getStringCellValue().trim();
                        Cell cell = currentRow.getCell(j);

                        switch (cell.getCellType()) {
                            case STRING:
                                rowData.put(columnName, cell.getStringCellValue().trim());
                                break;
                            case NUMERIC:
                                rowData.put(columnName, String.valueOf(cell.getNumericCellValue()));
                                break;
                            case BOOLEAN:
                                rowData.put(columnName, String.valueOf(cell.getBooleanCellValue()));
                                break;
                            default:
                                rowData.put(columnName, "");
                        }
                    }
                }

                if (currentRow != null && currentRow.getCell(0) != null) {
                    String key = currentRow.getCell(0).getStringCellValue().trim();
                    excelData.put(key, rowData);
                    System.out.println("Loaded key: " + key); // Debugging: Print each key loaded
                }
            }
        }
        return excelData;
    }}