package Constants;

public class Constatine {
	public static String Appurl;
	public static String BROWSER;
	public static String USERNAME;
	public static String PASSWORD;
	public static String InvalidUsername;
	public static String InvalidPassword;
	

}
