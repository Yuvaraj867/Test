package Utiliss;

import java.io.File;

import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


import com.lao.pageobjects.IFAC_Login;


import Constants.Constatine;
import WEBDRIVER_Manager.DriverManager;



public class CommonUtilis {
	
	private static CommonUtilis commonutilisinstance=null;
	
	private CommonUtilis() {
		
	}
	
	
	
	public static CommonUtilis getCommonutilisinstance() {
		if(commonutilisinstance==null) {
			commonutilisinstance=new CommonUtilis();
			
		}
		return commonutilisinstance;
	}
	WebDriverWait wait;
	
	
	
		public void loadProperties() throws IOException {
        

        // Load Excel file
			 
			 FileInputStream file = new FileInputStream(new File("D:\\Excel\\Login_Data.xlsx"));
			 
		        XSSFWorkbook workbook = new XSSFWorkbook(file);
		        
		        XSSFSheet sheet = workbook.getSheet("Sheet1");
		        

		      int rowCount = sheet.getLastRowNum();
		     int columnCount = sheet.getRow(0).getLastCellNum();
        

				
		     
		  // Create a 2D array to store test data
		     String[][] testData = new String[rowCount][columnCount];

		     // Iterate over rows and columns to populate the test data array
		     for (int i = 1; i <= rowCount; i++) {
		         for (int j = 0; j < columnCount; j++) { // Corrected index range for columns
		             if (sheet.getRow(i) != null && sheet.getRow(i).getCell(j) != null) {
		                 // Check if the cell type is String; otherwise, handle it appropriately
		                 switch (sheet.getRow(i).getCell(j).getCellType()) {
		                     case STRING:
		                         testData[i - 1][j] = sheet.getRow(i).getCell(j).getStringCellValue();
		                         break;
		                     case NUMERIC:
		                         testData[i - 1][j] = String.valueOf(sheet.getRow(i).getCell(j).getNumericCellValue());
		                         break;
		                     case BOOLEAN:
		                         testData[i - 1][j] = String.valueOf(sheet.getRow(i).getCell(j).getBooleanCellValue());
		                         break;
		                     default:
		                         testData[i - 1][j] = ""; // Handle blank or unsupported types
		                 }
		                
		             } else {
		                 testData[i - 1][j] = ""; // Assign empty string if cell is null
		             }
		         }
		     }

		     // Iterate over test data to perform login actions
		     for (int i = 0; i < rowCount; i++) {
		         // Get URL, username, and password from Excel
		         Constatine.BROWSER = testData[i][0];
		         Constatine.Appurl = testData[i][1];
		         Constatine.USERNAME = testData[i][2];
		         Constatine.PASSWORD = testData[i][3];
		         Constatine.InvalidUsername = testData[i][4];
		         Constatine.InvalidPassword = testData[i][5];
		     }
     workbook.close();
		}
            
            



	
	
	 
		
	public void intelements() {
	
		PageFactory.initElements(DriverManager.getDriver(), IFAC_Login.getInstance());
		
	}
		
	public void takescreenshot()  {

		  TakesScreenshot screenimg = (TakesScreenshot)DriverManager.getDriver();
		  File filess =screenimg.getScreenshotAs(OutputType.FILE); 
		  try {
			  FileUtils.copyFile(filess, new File("screenshot.png"));
		} catch (IOException e) {
			System.out.println(e.getMessage());
			
		}
	
	}
	
	public  void WaitForElementVisibility(By username) {
		wait = new WebDriverWait(DriverManager.getDriver(), Duration.ofSeconds(30));
		wait.until(ExpectedConditions.visibilityOfElementLocated((By) username));

	}

	public  void WaitForElementTobeClickable(By element) {
		wait = new WebDriverWait(DriverManager.getDriver(), Duration.ofSeconds(30));
		wait.until(ExpectedConditions.elementToBeClickable(element));

	}
	  
	public void hihlightelement(WebElement element){
		JavascriptExecutor executor = (JavascriptExecutor) DriverManager.getDriver();
		executor.executeScript("arguments[0].setAttribute('style','border: 3px solid blue');",element);
		 
	}
	
	
	
	public void selectdropdown (WebElement Dropdown,String howto ,String value) {
		Select select = new Select(Dropdown);
		
		switch (howto) {
		case "index":
			select.selectByIndex(Integer.parseInt(value));
			break;
		case "value":
			select.selectByIndex(Integer.parseInt(value));
			break;
		case "text":
			select.selectByIndex(Integer.parseInt(value));
			break;
			
			

		default:
			break;
			
			

		}
	}
	
	public void selectOptionFromDivListBox(By listboxLocator, String visibleText) {
        WebElement listboxElement = wait.until(ExpectedConditions.visibilityOfElementLocated(listboxLocator));
        List<WebElement> options = listboxElement.findElements(By.xpath("//*[@class='k-list-content']/ul/li"));
        for (WebElement option : options) {
            if (option.getText().equals(visibleText)) {
                option.click();
                break;
            }
        }


		
	}}
		
		
	
	
	


