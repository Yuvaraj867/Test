package WEBDRIVER_Manager;

import java.time.Duration;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

import com.stepdefinitions.Common_Step_definition;

import Constants.Constatine;
import io.github.bonigarcia.wdm.WebDriverManager;

public class DriverManager {
	
	    private static WebDriver driver = null;
	 //   private static final Logger logger = Logger.getLogger(DriverManager.class);

	    public static WebDriver getDriver() {
	        return driver;
	    }

	    public static void Launchbrowser() {
	        PropertyConfigurator.configure("File2.properties");
	        String browser = System.getProperty("browser", "chrome");

	        try {
	            if (driver == null) {
	                switch (browser.toLowerCase()) {
	                    case "chrome":
	                        WebDriverManager.chromedriver().setup();
	                        ChromeOptions chromeOptions = new ChromeOptions();
	                        chromeOptions.addArguments("--start-maximized");
	                        chromeOptions.addArguments("--disable-web-security"); // Disable web security to allow http
	                        chromeOptions.addArguments("--allow-running-insecure-content"); // Allow insecure content
	                        chromeOptions.setAcceptInsecureCerts(true); // Accept insecure certificates
	                        driver = new ChromeDriver(chromeOptions);
	                     //   logger.info("Chrome browser launched with HTTP-only settings");
	                        break;

	                    case "edge":
	                        WebDriverManager.edgedriver().setup();
	                        EdgeOptions edgeOptions = new EdgeOptions();
	                        edgeOptions.addArguments("--start-maximized");
	                        edgeOptions.addArguments("--disable-web-security");
	                        edgeOptions.addArguments("--allow-running-insecure-content");
	                        edgeOptions.setAcceptInsecureCerts(true);
	                        driver = new EdgeDriver(edgeOptions);
	                       // logger.info("Edge browser launched with HTTP-only settings");
	                        break;

	                    default:
	                        WebDriverManager.chromedriver().setup();
	                        driver = new ChromeDriver();
	                       // logger.warn("Unknown browser specified, defaulting to Chrome");
	                        break;
	                }

	                // Set global implicit wait
	                driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	            }

	        } catch (Exception e) {
	           // logger.error("Error occurred while launching the browser", e);
	            e.printStackTrace();
	        }
	    }

	    public static void closedriver() {
	        if (driver != null) {
	            driver.quit();
	            driver = null;
	           // logger.info("Browser closed and WebDriver instance set to null");
	        }
	    }}